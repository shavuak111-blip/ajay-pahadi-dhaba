package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.CartItem
import com.example.data.model.DishItem
import com.example.data.model.OrderType
import com.example.data.repository.DhabaRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read app name string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Ajay Pahadi Dhaba", appName)
  }

  @Test
  fun `verify whatsapp message generation`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val repo = DhabaRepository(
      com.example.data.local.DhabaDatabase.getDatabase(context).dhabaDao(),
      context
    )

    val sampleDish = DishItem(
      id = "tawa_chicken",
      name = "Special Tawa Chicken",
      category = "SPECIAL_CHICKEN",
      description = "Slow cooked on iron tawa",
      isVeg = false,
      price = 320.0
    )

    val message = repo.generateWhatsAppMessage(
      orderId = "APD-2026-101",
      customerName = "Rahul Sharma",
      phone = "+91 9876543210",
      address = "Near Mall Road, Himachal",
      orderType = OrderType.DELIVERY,
      items = listOf(CartItem(dish = sampleDish, quantity = 2)),
      specialInstructions = "Make it spicy",
      totalAmount = 640.0,
      showPrices = true
    )

    assertTrue(message.contains("AJAY PAHADI DHABA"))
    assertTrue(message.contains("Special Tawa Chicken"))
    assertTrue(message.contains("Rahul Sharma"))
    assertTrue(message.contains("Near Mall Road"))
  }
}
