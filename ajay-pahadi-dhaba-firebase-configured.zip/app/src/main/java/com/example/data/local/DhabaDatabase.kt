package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(entities = [DishEntity::class, OrderEntity::class, SettingsEntity::class], version = 1, exportSchema = false)
abstract class DhabaDatabase : RoomDatabase() {

  abstract fun dhabaDao(): DhabaDao

  companion object {
    @Volatile
    private var INSTANCE: DhabaDatabase? = null

    fun getDatabase(context: Context): DhabaDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          DhabaDatabase::class.java,
          "ajay_pahadi_dhaba_db"
        )
        .addCallback(DatabaseCallback())
        .build()
        INSTANCE = instance
        instance
      }
    }
  }

  private class DatabaseCallback : RoomDatabase.Callback() {
    override fun onCreate(db: SupportSQLiteDatabase) {
      super.onCreate(db)
      INSTANCE?.let { database ->
        CoroutineScope(Dispatchers.IO).launch {
          populateInitialMenu(database.dhabaDao())
        }
      }
    }

    suspend fun populateInitialMenu(dao: DhabaDao) {
      val initialDishes = listOf(
        // A. SPECIAL CHICKEN
        DishEntity(
          id = "tawa_chicken",
          name = "Special Tawa Chicken",
          category = "SPECIAL_CHICKEN",
          description = "Ajay Dhaba's signature dish. Tender country chicken marinated in secret pahadi whole spices, slow-roasted to perfection on a cast-iron tawa with crushed coriander seeds and green chilies.",
          isVeg = false,
          price = null,
          isAvailable = true,
          isSundayOnly = false,
          mealTimes = "LUNCH,DINNER",
          imageIdentifier = "tawa_chicken",
          isSpecial = true,
          isPopular = true
        ),
        DishEntity(
          id = "crispy_fry_chicken",
          name = "Crispy Fry Chicken",
          category = "SPECIAL_CHICKEN",
          description = "Crispy golden fried spiced chicken bites coated with roasted cumin, carom seeds and garlic-ginger paste. Served with spicy mint chutney.",
          isVeg = false,
          price = null,
          isAvailable = true,
          isSundayOnly = false,
          mealTimes = "LUNCH,DINNER",
          imageIdentifier = "fry_chicken",
          isSpecial = false,
          isPopular = true
        ),
        DishEntity(
          id = "chicken_gravy",
          name = "Chicken Gravy",
          category = "SPECIAL_CHICKEN",
          description = "Traditional rustic chicken curry slow simmered with browned onions, tomatoes, and hand-pounded mountain spices. Rich, aromatic and soul-satisfying.",
          isVeg = false,
          price = null,
          isAvailable = true,
          isSundayOnly = false,
          mealTimes = "LUNCH,DINNER",
          imageIdentifier = "chicken_gravy",
          isSpecial = false,
          isPopular = false
        ),
        DishEntity(
          id = "chicken_thali",
          name = "Chicken Thali",
          category = "SPECIAL_CHICKEN",
          description = "Complete wholesome feast featuring spicy chicken curry, pahadi dal, fragrant steamed rice, 4 fresh butter rotis, sliced onion salad and pickle.",
          isVeg = false,
          price = null,
          isAvailable = true,
          isSundayOnly = false,
          mealTimes = "LUNCH,DINNER",
          imageIdentifier = "chicken_thali",
          isSpecial = true,
          isPopular = true
        ),

        // B. EGG SPECIALS
        DishEntity(
          id = "egg_curry",
          name = "Egg Curry",
          category = "EGG_SPECIALS",
          description = "Golden-pan-seared fresh farm eggs cooked in an authentic onion-tomato-ginger spiced dhaba masala gravy.",
          isVeg = false,
          price = null,
          isAvailable = true,
          isSundayOnly = false,
          mealTimes = "LUNCH,DINNER",
          imageIdentifier = "egg_curry",
          isSpecial = false,
          isPopular = true
        ),
        DishEntity(
          id = "egg_roll",
          name = "Egg Roll",
          category = "EGG_SPECIALS",
          description = "Crispy layered flaky parantha wrapped with fluffy double eggs, crunchy onions, green chilies and dhaba tangy chaat seasoning.",
          isVeg = false,
          price = null,
          isAvailable = true,
          isSundayOnly = false,
          mealTimes = "BREAKFAST,LUNCH,DINNER",
          imageIdentifier = "egg_roll",
          isSpecial = false,
          isPopular = false
        ),

        // C. INDIAN MEALS
        DishEntity(
          id = "veg_thali",
          name = "Veg Thali",
          category = "INDIAN_MEALS",
          description = "Authentic Ghar Jaisa Swad platter: Pahadi Dal Makhani/Tadka, seasonal fresh vegetable subzi, steamed basmati rice, 4 tawa rotis, salad and raita.",
          isVeg = true,
          price = null,
          isAvailable = true,
          isSundayOnly = false,
          mealTimes = "LUNCH,DINNER",
          imageIdentifier = "veg_thali",
          isSpecial = false,
          isPopular = true
        ),
        DishEntity(
          id = "steamed_rice",
          name = "Rice",
          category = "INDIAN_MEALS",
          description = "Long-grain Himalayan basmati rice, freshly boiled and fragrant.",
          isVeg = true,
          price = null,
          isAvailable = true,
          isSundayOnly = false,
          mealTimes = "LUNCH,DINNER",
          imageIdentifier = "rice",
          isSpecial = false,
          isPopular = false
        ),
        DishEntity(
          id = "rajma_rice",
          name = "Rajma Rice",
          category = "INDIAN_MEALS",
          description = "Himachal's famous red kidney beans slow-simmered with pahadi herbs and pure desi ghee, served with hot steamed basmati rice.",
          isVeg = true,
          price = null,
          isAvailable = true,
          isSundayOnly = false,
          mealTimes = "LUNCH,DINNER",
          imageIdentifier = "rajma_rice",
          isSpecial = true,
          isPopular = true
        ),
        DishEntity(
          id = "dal_rice",
          name = "Dal Rice",
          category = "INDIAN_MEALS",
          description = "Comforting yellow dal with double heeng-jeera tadka served over fragrant steamed rice with homemade mixed pickle.",
          isVeg = true,
          price = null,
          isAvailable = true,
          isSundayOnly = false,
          mealTimes = "LUNCH,DINNER",
          imageIdentifier = "dal_rice",
          isSpecial = false,
          isPopular = false
        ),

        // D. ROTI
        DishEntity(
          id = "butter_roti",
          name = "Butter Roti",
          category = "ROTI",
          description = "Freshly cooked hot whole wheat flatbread smothered with generous fresh churned creamy butter.",
          isVeg = true,
          price = null,
          isAvailable = true,
          isSundayOnly = false,
          mealTimes = "LUNCH,DINNER",
          imageIdentifier = "butter_roti",
          isSpecial = false,
          isPopular = true
        ),
        DishEntity(
          id = "plain_chapati",
          name = "Plain Chapati",
          category = "ROTI",
          description = "Soft, light and healthy whole wheat phulka baked fresh upon your order.",
          isVeg = true,
          price = null,
          isAvailable = true,
          isSundayOnly = false,
          mealTimes = "LUNCH,DINNER",
          imageIdentifier = "chapati",
          isSpecial = false,
          isPopular = false
        ),

        // E. BREAKFAST
        DishEntity(
          id = "aloo_parantha",
          name = "Aloo Parantha",
          category = "BREAKFAST",
          description = "Traditional crispy whole-wheat flatbread generously stuffed with spiced mashed potatoes, fresh coriander and roasted anardana. Served with butter & pickle.",
          isVeg = true,
          price = null,
          isAvailable = true,
          isSundayOnly = false,
          mealTimes = "BREAKFAST",
          imageIdentifier = "aloo_parantha",
          isSpecial = true,
          isPopular = true
        ),
        DishEntity(
          id = "paneer_parantha",
          name = "Paneer Parantha",
          category = "BREAKFAST",
          description = "Crispy golden parantha filled with fresh crumbly spiced cottage cheese, green chilies and ajwain. Served with curd and fresh butter.",
          isVeg = true,
          price = null,
          isAvailable = true,
          isSundayOnly = false,
          mealTimes = "BREAKFAST",
          imageIdentifier = "paneer_parantha",
          isSpecial = false,
          isPopular = true
        ),
        DishEntity(
          id = "mix_veg_parantha",
          name = "Mix Veg Parantha",
          category = "BREAKFAST",
          description = "Stuffed with seasoned carrots, cauliflower, potatoes and green peas. Healthy and crispy mountain breakfast.",
          isVeg = true,
          price = null,
          isAvailable = true,
          isSundayOnly = false,
          mealTimes = "BREAKFAST",
          imageIdentifier = "mix_parantha",
          isSpecial = false,
          isPopular = false
        ),
        DishEntity(
          id = "gobhi_parantha",
          name = "Gobhi Parantha",
          category = "BREAKFAST",
          description = "Grated fresh cauliflower spiced with ginger, green chillies and roasted garam masala.",
          isVeg = true,
          price = null,
          isAvailable = true,
          isSundayOnly = false,
          mealTimes = "BREAKFAST",
          imageIdentifier = "gobhi_parantha",
          isSpecial = false,
          isPopular = false
        ),

        // F. CHINESE AND SNACKS
        DishEntity(
          id = "chowmein",
          name = "Chowmein",
          category = "CHINESE_SNACKS",
          description = "Desi dhaba wok-tossed street noodles with shredded cabbage, capsicum, onions, dark soy and spicy mountain chilli sauce.",
          isVeg = true,
          price = null,
          isAvailable = true,
          isSundayOnly = false,
          mealTimes = "LUNCH,DINNER",
          imageIdentifier = "chowmein",
          isSpecial = false,
          isPopular = true
        ),
        DishEntity(
          id = "burger",
          name = "Burger",
          category = "CHINESE_SNACKS",
          description = "Crispy spiced potato & pea patty inside toasted soft buns layered with onion rings, tomato slice and signature dhaba tangy mayo.",
          isVeg = true,
          price = null,
          isAvailable = true,
          isSundayOnly = false,
          mealTimes = "LUNCH,DINNER",
          imageIdentifier = "burger",
          isSpecial = false,
          isPopular = false
        ),
        DishEntity(
          id = "spring_roll",
          name = "Spring Roll",
          category = "CHINESE_SNACKS",
          description = "Golden crunchy rolls packed with spiced stir-fried vegetables and glass noodles. Served with sweet chili dipping sauce.",
          isVeg = true,
          price = null,
          isAvailable = true,
          isSundayOnly = false,
          mealTimes = "LUNCH,DINNER",
          imageIdentifier = "spring_roll",
          isSpecial = false,
          isPopular = false
        ),
        DishEntity(
          id = "fried_rice",
          name = "Fried Rice",
          category = "CHINESE_SNACKS",
          description = "Aromatic basmati rice stir-fried in a high-flame wok with crunchy garden vegetables, spring onions and garlic soy seasoning.",
          isVeg = true,
          price = null,
          isAvailable = true,
          isSundayOnly = false,
          mealTimes = "LUNCH,DINNER",
          imageIdentifier = "fried_rice",
          isSpecial = false,
          isPopular = false
        ),
        DishEntity(
          id = "chicken_pakora",
          name = "Chicken Pakora",
          category = "CHINESE_SNACKS",
          description = "Juicy chicken bites dipped in ajwain-scented spiced gram flour batter and double fried for an irresistible crunch.",
          isVeg = false,
          price = null,
          isAvailable = true,
          isSundayOnly = false,
          mealTimes = "LUNCH,DINNER",
          imageIdentifier = "chicken_pakora",
          isSpecial = true,
          isPopular = true
        ),

        // G. BEVERAGES
        DishEntity(
          id = "pahadi_chai",
          name = "Tea / Chai",
          category = "BEVERAGES",
          description = "Signature Pahadi Adrak Elaichi Chai, slow brewed with fresh crushed mountain ginger, green cardamom and thick milk. A piping hot cup of heaven.",
          isVeg = true,
          price = null,
          isAvailable = true,
          isSundayOnly = false,
          mealTimes = "BREAKFAST,LUNCH,DINNER",
          imageIdentifier = "tea_chai",
          isSpecial = true,
          isPopular = true
        ),
        DishEntity(
          id = "mineral_water",
          name = "Mineral Water",
          category = "BEVERAGES",
          description = "Chilled sealed packaged mineral drinking water (1 Litre).",
          isVeg = true,
          price = null,
          isAvailable = true,
          isSundayOnly = false,
          mealTimes = "BREAKFAST,LUNCH,DINNER",
          imageIdentifier = "mineral_water",
          isSpecial = false,
          isPopular = false
        ),
        DishEntity(
          id = "khara_soda",
          name = "Khara Soda",
          category = "BEVERAGES",
          description = "Crisp chilled club soda served with fresh lemon wedge and black rock salt seasoning on request.",
          isVeg = true,
          price = null,
          isAvailable = true,
          isSundayOnly = false,
          mealTimes = "BREAKFAST,LUNCH,DINNER",
          imageIdentifier = "khara_soda",
          isSpecial = false,
          isPopular = false
        ),

        // H. SUNDAY SPECIAL
        DishEntity(
          id = "sunday_mutton",
          name = "Mutton",
          category = "SUNDAY_SPECIAL",
          description = "Exclusive Sunday Special. Hand-selected tender mountain goat meat slow-cooked in a brass handi over woodfire with aromatic whole spices, black cardamom and pahadi herbs.",
          isVeg = false,
          price = null,
          isAvailable = true,
          isSundayOnly = true,
          mealTimes = "LUNCH,DINNER",
          imageIdentifier = "sunday_mutton",
          isSpecial = true,
          isPopular = true
        ),
        DishEntity(
          id = "sunday_mutton_curry",
          name = "Mutton Curry",
          category = "SUNDAY_SPECIAL",
          description = "Rich, deep red mutton gravy infused with roasted spices, garlic paste and pure ghee. Made in limited quantities every Sunday.",
          isVeg = false,
          price = null,
          isAvailable = true,
          isSundayOnly = true,
          mealTimes = "LUNCH,DINNER",
          imageIdentifier = "mutton_curry",
          isSpecial = true,
          isPopular = false
        ),
        DishEntity(
          id = "sunday_keema_roti",
          name = "Keema Roti",
          category = "SUNDAY_SPECIAL",
          description = "Freshly rolled parantha stuffed with spicy minced mutton and herbs, roasted crisp on iron tawa.",
          isVeg = false,
          price = null,
          isAvailable = true,
          isSundayOnly = true,
          mealTimes = "LUNCH,DINNER",
          imageIdentifier = "keema_roti",
          isSpecial = false,
          isPopular = false
        )
      )

      dao.insertDishes(initialDishes)

      // Initialize default settings: prices hidden by default per user rule
      dao.saveSettings(
        SettingsEntity(
          id = 1,
          showPrices = false,
          forceSundaySpecial = false,
          isRestaurantOpen = true,
          deliveryCharge = 0.0
        )
      )
    }
  }
}
