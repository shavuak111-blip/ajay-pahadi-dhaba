package com.example.data.repository

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.example.data.local.DhabaDao
import com.example.data.local.DishEntity
import com.example.data.local.OrderEntity
import com.example.data.local.SettingsEntity
import com.example.data.model.CartItem
import com.example.data.model.DhabaSettings
import com.example.data.model.DishItem
import com.example.data.model.OrderRecord
import com.example.data.model.OrderStatus
import com.example.data.model.OrderType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.Calendar

class DhabaRepository(
  private val dhabaDao: DhabaDao,
  private val context: Context
) {

  companion object {
    const val RESTAURANT_PHONE = "+91 93174 04470"
    const val RESTAURANT_RAW_PHONE = "919317404470"
    const val RESTAURANT_NAME = "Ajay Pahadi Dhaba"
    const val RESTAURANT_TAGLINE = "Ghar Jaisa Swad, Pahadon Wala Pyaar"
    const val RESTAURANT_LOCATION = "Himachal Pradesh, India"
  }

  val allDishesFlow: Flow<List<DishItem>> = dhabaDao.getAllDishes().map { entities ->
    entities.map { it.toDomain() }
  }

  val settingsFlow: Flow<DhabaSettings> = dhabaDao.getSettings().map { entity ->
    entity?.toDomain() ?: DhabaSettings()
  }

  val ordersFlow: Flow<List<OrderRecord>> = dhabaDao.getAllOrders().map { entities ->
    entities.map { it.toDomain() }
  }

  suspend fun ensureMenuPopulated() = withContext(Dispatchers.IO) {
    if (dhabaDao.getDishCount() == 0) {
      // populate if empty
      val db = com.example.data.local.DhabaDatabase.getDatabase(context)
      // The callback will populate, or fallback insert:
    }
  }

  fun isTodaySunday(): Boolean {
    val calendar = Calendar.getInstance()
    return calendar.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY
  }

  suspend fun updateDishAvailability(dishId: String, isAvailable: Boolean) = withContext(Dispatchers.IO) {
    dhabaDao.updateAvailability(dishId, isAvailable)
  }

  suspend fun updateDishPrice(dishId: String, price: Double?) = withContext(Dispatchers.IO) {
    dhabaDao.updatePrice(dishId, price)
  }

  suspend fun saveDish(dish: DishItem) = withContext(Dispatchers.IO) {
    dhabaDao.insertDish(dish.toEntity())
  }

  suspend fun deleteDish(dishId: String) = withContext(Dispatchers.IO) {
    dhabaDao.deleteDish(dishId)
  }

  suspend fun updateSettings(settings: DhabaSettings) = withContext(Dispatchers.IO) {
    dhabaDao.saveSettings(
      SettingsEntity(
        id = 1,
        showPrices = settings.showPrices,
        forceSundaySpecial = settings.forceSundaySpecial,
        isRestaurantOpen = settings.isRestaurantOpen,
        deliveryCharge = settings.deliveryCharge
      )
    )
  }

  suspend fun updateOrderStatus(orderId: String, status: OrderStatus) = withContext(Dispatchers.IO) {
    dhabaDao.updateOrderStatus(orderId, status.name)
  }

  suspend fun saveOrder(
    customerName: String,
    phone: String,
    address: String,
    orderType: OrderType,
    items: List<CartItem>,
    specialInstructions: String,
    totalAmount: Double?,
    deliveryFee: Double
  ): OrderRecord = withContext(Dispatchers.IO) {
    val randomSuffix = (1000..9999).random()
    val orderId = "APD-2026-$randomSuffix"

    val itemsJson = JSONArray().apply {
      items.forEach { cartItem ->
        put(JSONObject().apply {
          put("id", cartItem.dish.id)
          put("name", cartItem.dish.name)
          put("quantity", cartItem.quantity)
          put("isVeg", cartItem.dish.isVeg)
          put("price", cartItem.dish.price ?: -1.0)
        })
      }
    }.toString()

    val entity = OrderEntity(
      id = orderId,
      customerName = customerName,
      phone = phone,
      address = address,
      orderType = orderType.name,
      itemsJson = itemsJson,
      specialInstructions = specialInstructions,
      totalAmount = totalAmount,
      deliveryFee = deliveryFee,
      status = OrderStatus.RECEIVED.name,
      timestamp = System.currentTimeMillis()
    )

    dhabaDao.insertOrder(entity)
    entity.toDomain()
  }

  fun generateWhatsAppMessage(
    orderId: String?,
    customerName: String,
    phone: String,
    address: String,
    orderType: OrderType,
    items: List<CartItem>,
    specialInstructions: String,
    totalAmount: Double?,
    showPrices: Boolean
  ): String {
    val sb = StringBuilder()
    sb.append("🥘 *AJAY PAHADI DHABA - NEW ORDER*\n")
    sb.append("_Ghar Jaisa Swad, Pahadon Wala Pyaar_\n")
    sb.append("📍 $RESTAURANT_LOCATION\n\n")

    if (!orderId.isNullOrBlank()) {
      sb.append("🔖 *Order ID:* $orderId\n")
    }
    sb.append("🛵 *Order Type:* ${orderType.displayName}\n")
    sb.append("━━━━━━━━━━━━━━━━━━━━\n")
    sb.append("📋 *ITEMS ORDERED:*\n")

    items.forEach { cartItem ->
      val vegBadge = if (cartItem.dish.isVeg) "🟢 [VEG]" else "🔴 [NON-VEG]"
      val priceStr = if (showPrices && cartItem.dish.price != null && cartItem.dish.price > 0) {
        " - ₹${String.format("%.0f", cartItem.dish.price * cartItem.quantity)}"
      } else ""
      sb.append("• ${cartItem.quantity}x ${cartItem.dish.name} $vegBadge$priceStr\n")
    }

    if (specialInstructions.isNotBlank()) {
      sb.append("\n📝 *Special Instructions:*\n\"$specialInstructions\"\n")
    }

    sb.append("━━━━━━━━━━━━━━━━━━━━\n")
    sb.append("👤 *CUSTOMER DETAILS:*\n")
    sb.append("• Name: $customerName\n")
    sb.append("• Phone: $phone\n")
    if (orderType == OrderType.DELIVERY) {
      sb.append("• Delivery Address: $address\n")
      sb.append("• Delivery Zone: Within 0–3 km (Free Delivery)\n")
    } else {
      sb.append("• Pickup: At Dhaba Counter\n")
    }

    sb.append("━━━━━━━━━━━━━━━━━━━━\n")
    if (showPrices && totalAmount != null && totalAmount > 0) {
      sb.append("💰 *Total Amount:* ₹${String.format("%.0f", totalAmount)}\n")
    } else {
      sb.append("💰 *Total:* [Please confirm final amount on WhatsApp]\n")
    }
    sb.append("\nPlease accept and confirm this order. Thank you! 🙏")
    return sb.toString()
  }

  fun launchWhatsApp(context: Context, message: String): Boolean {
    return try {
      val encoded = URLEncoder.encode(message, StandardCharsets.UTF_8.toString())
      val uri = Uri.parse("https://api.whatsapp.com/send?phone=$RESTAURANT_RAW_PHONE&text=$encoded")
      val intent = Intent(Intent.ACTION_VIEW, uri).apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      }
      context.startActivity(intent)
      true
    } catch (e: Exception) {
      false
    }
  }

  // Extensions
  private fun DishEntity.toDomain() = DishItem(
    id = id,
    name = name,
    category = category,
    description = description,
    isVeg = isVeg,
    price = price,
    isAvailable = isAvailable,
    isSundayOnly = isSundayOnly,
    mealTimes = mealTimes.split(",").filter { it.isNotBlank() },
    imageIdentifier = imageIdentifier,
    isSpecial = isSpecial,
    isPopular = isPopular
  )

  private fun DishItem.toEntity() = DishEntity(
    id = id,
    name = name,
    category = category,
    description = description,
    isVeg = isVeg,
    price = price,
    isAvailable = isAvailable,
    isSundayOnly = isSundayOnly,
    mealTimes = mealTimes.joinToString(","),
    imageIdentifier = imageIdentifier,
    isSpecial = isSpecial,
    isPopular = isPopular
  )

  private fun SettingsEntity.toDomain() = DhabaSettings(
    showPrices = showPrices,
    forceSundaySpecial = forceSundaySpecial,
    isRestaurantOpen = isRestaurantOpen,
    deliveryCharge = deliveryCharge
  )

  private fun OrderEntity.toDomain(): OrderRecord {
    val parsedItems = mutableListOf<CartItem>()
    try {
      val jsonArray = JSONArray(itemsJson)
      for (i in 0 until jsonArray.length()) {
        val obj = jsonArray.getJSONObject(i)
        val priceVal = obj.optDouble("price", -1.0)
        parsedItems.add(
          CartItem(
            dish = DishItem(
              id = obj.getString("id"),
              name = obj.getString("name"),
              category = "FOOD",
              description = "",
              isVeg = obj.optBoolean("isVeg", true),
              price = if (priceVal >= 0) priceVal else null
            ),
            quantity = obj.getInt("quantity")
          )
        )
      }
    } catch (_: Exception) {
    }

    return OrderRecord(
      id = id,
      customerName = customerName,
      phone = phone,
      address = address,
      orderType = try { OrderType.valueOf(orderType) } catch (_: Exception) { OrderType.DELIVERY },
      items = parsedItems,
      specialInstructions = specialInstructions,
      totalAmount = totalAmount,
      deliveryFee = deliveryFee,
      status = try { OrderStatus.valueOf(status) } catch (_: Exception) { OrderStatus.RECEIVED },
      timestamp = timestamp
    )
  }
}
