package com.example.data.model

enum class MenuCategory(val displayName: String, val tagline: String) {
  SPECIAL_CHICKEN("Special Chicken", "Iron Tawa & Rich Gravy Delicacies"),
  EGG_SPECIALS("Egg Specials", "Farm Fresh Curries & Rolls"),
  INDIAN_MEALS("Indian Meals", "Wholesome Pahadi Thalis & Rice"),
  ROTI("Roti", "Fresh Tawa & Phulka Breads"),
  BREAKFAST("Breakfast", "Stuffed Paranthas with Butter"),
  CHINESE_SNACKS("Chinese & Snacks", "Crispy Starters & Pakoras"),
  BEVERAGES("Beverages", "Fresh Pahadi Chai & Sodas"),
  SUNDAY_SPECIAL("Sunday Special", "Slow Cooked Woodfire Mutton Handi");

  companion object {
    fun fromString(value: String): MenuCategory {
      return entries.find { it.name.equals(value, ignoreCase = true) } ?: SPECIAL_CHICKEN
    }
  }
}

enum class MealFilter(val label: String) {
  ALL("All Dishes"),
  BREAKFAST("Breakfast"),
  LUNCH("Lunch"),
  DINNER("Dinner")
}

data class DishItem(
  val id: String,
  val name: String,
  val category: String,
  val description: String,
  val isVeg: Boolean,
  val price: Double? = null,
  val isAvailable: Boolean = true,
  val isSundayOnly: Boolean = false,
  val mealTimes: List<String> = listOf("LUNCH", "DINNER"),
  val imageIdentifier: String = "tawa_chicken",
  val isSpecial: Boolean = false,
  val isPopular: Boolean = false
)

data class CartItem(
  val dish: DishItem,
  val quantity: Int = 1
)

enum class OrderType(val displayName: String) {
  DELIVERY("Doorstep Delivery (0-3 km)"),
  PICKUP("Self Pickup / Takeaway")
}

enum class OrderStatus(val title: String, val badgeColorHex: Long) {
  RECEIVED("Order Received", 0xFFD97706),
  PREPARING("Cooking in Kitchen", 0xFFEA580C),
  OUT_FOR_DELIVERY("Out for Delivery / Ready", 0xFF2563EB),
  COMPLETED("Completed", 0xFF16A34A),
  CANCELLED("Cancelled", 0xFFDC2626)
}

data class OrderRecord(
  val id: String,
  val customerName: String,
  val phone: String,
  val address: String,
  val orderType: OrderType,
  val items: List<CartItem>,
  val specialInstructions: String,
  val totalAmount: Double?,
  val deliveryFee: Double = 0.0,
  val status: OrderStatus = OrderStatus.RECEIVED,
  val timestamp: Long = System.currentTimeMillis()
)

data class DhabaSettings(
  val showPrices: Boolean = false,
  val forceSundaySpecial: Boolean = false,
  val isRestaurantOpen: Boolean = true,
  val deliveryCharge: Double = 0.0,
  val freeDeliveryRadiusKm: Double = 3.0
)
