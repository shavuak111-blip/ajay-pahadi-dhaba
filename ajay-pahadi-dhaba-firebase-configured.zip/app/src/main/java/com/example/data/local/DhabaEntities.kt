package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "dishes")
data class DishEntity(
  @PrimaryKey val id: String,
  val name: String,
  val category: String,
  val description: String,
  val isVeg: Boolean,
  val price: Double?,
  val isAvailable: Boolean,
  val isSundayOnly: Boolean,
  val mealTimes: String,
  val imageIdentifier: String,
  val isSpecial: Boolean,
  val isPopular: Boolean
)

@Entity(tableName = "orders")
data class OrderEntity(
  @PrimaryKey val id: String,
  val customerName: String,
  val phone: String,
  val address: String,
  val orderType: String,
  val itemsJson: String,
  val specialInstructions: String,
  val totalAmount: Double?,
  val deliveryFee: Double,
  val status: String,
  val timestamp: Long
)

@Entity(tableName = "settings")
data class SettingsEntity(
  @PrimaryKey val id: Int = 1,
  val showPrices: Boolean = false,
  val forceSundaySpecial: Boolean = false,
  val isRestaurantOpen: Boolean = true,
  val deliveryCharge: Double = 0.0
)
