package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface DhabaDao {

  @Query("SELECT * FROM dishes ORDER BY category, name")
  fun getAllDishes(): Flow<List<DishEntity>>

  @Query("SELECT * FROM dishes WHERE id = :id LIMIT 1")
  suspend fun getDishById(id: String): DishEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertDish(dish: DishEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertDishes(dishes: List<DishEntity>)

  @Update
  suspend fun updateDish(dish: DishEntity)

  @Query("UPDATE dishes SET isAvailable = :isAvailable WHERE id = :id")
  suspend fun updateAvailability(id: String, isAvailable: Boolean)

  @Query("UPDATE dishes SET price = :price WHERE id = :id")
  suspend fun updatePrice(id: String, price: Double?)

  @Query("DELETE FROM dishes WHERE id = :id")
  suspend fun deleteDish(id: String)

  @Query("SELECT COUNT(*) FROM dishes")
  suspend fun getDishCount(): Int

  // Orders
  @Query("SELECT * FROM orders ORDER BY timestamp DESC")
  fun getAllOrders(): Flow<List<OrderEntity>>

  @Query("SELECT * FROM orders WHERE id = :orderId LIMIT 1")
  suspend fun getOrderById(orderId: String): OrderEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertOrder(order: OrderEntity)

  @Query("UPDATE orders SET status = :status WHERE id = :orderId")
  suspend fun updateOrderStatus(orderId: String, status: String)

  // Settings
  @Query("SELECT * FROM settings WHERE id = 1 LIMIT 1")
  fun getSettings(): Flow<SettingsEntity?>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun saveSettings(settings: SettingsEntity)
}
