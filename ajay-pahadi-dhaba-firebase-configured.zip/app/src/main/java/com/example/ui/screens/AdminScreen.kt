package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.RestaurantMenu
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DhabaSettings
import com.example.data.model.DishItem
import com.example.data.model.MenuCategory
import com.example.data.model.OrderRecord
import com.example.data.model.OrderStatus
import com.example.data.repository.DhabaRepository
import com.example.ui.components.VegBadge
import com.example.ui.theme.DhabaBorder
import com.example.ui.theme.DhabaGold
import com.example.ui.theme.DhabaGoldDark
import com.example.ui.theme.DhabaGoldLight
import com.example.ui.theme.DhabaRedContainer
import com.example.ui.theme.DhabaRedPrimary
import com.example.ui.theme.DhabaVegGreen
import com.example.ui.theme.DhabaWhatsAppGreen
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminScreen(
  isUnlocked: Boolean,
  settings: DhabaSettings,
  orders: List<OrderRecord>,
  dishes: List<DishItem>,
  editingDish: DishItem?,
  onUnlock: (String) -> Boolean,
  onLock: () -> Unit,
  onToggleShowPrices: (Boolean) -> Unit,
  onToggleForceSunday: (Boolean) -> Unit,
  onToggleRestaurantOpen: (Boolean) -> Unit,
  onToggleDishAvailability: (String, Boolean) -> Unit,
  onUpdateDishPrice: (String, Double?) -> Unit,
  onSetEditingDish: (DishItem?) -> Unit,
  onSaveDish: (DishItem) -> Unit,
  onDeleteDish: (String) -> Unit,
  onUpdateOrderStatus: (String, OrderStatus) -> Unit,
  onNotifyCustomerWhatsApp: (Context, OrderRecord) -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  var enteredPin by remember { mutableStateOf("") }
  var adminTab by remember { mutableIntStateOf(0) } // 0: Live Orders, 1: Menu Management, 2: Dhaba Settings

  if (!isUnlocked) {
    AdminPinLockView(
      pin = enteredPin,
      onPinChange = { enteredPin = it },
      onUnlockClick = { onUnlock(enteredPin) },
      modifier = modifier
    )
    return
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .testTag("admin_screen_content")
  ) {
    // Admin Top Bar
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .background(DhabaRedPrimary)
        .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Default.AdminPanelSettings,
            contentDescription = null,
            tint = DhabaGold,
            modifier = Modifier.size(24.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "Dhaba Owner Dashboard",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Black,
            color = Color.White
          )
        }

        IconButton(
          onClick = onLock,
          modifier = Modifier.testTag("admin_lock_button")
        ) {
          Icon(
            imageVector = Icons.Default.Lock,
            contentDescription = "Lock",
            tint = Color.White
          )
        }
      }
    }

    // Tabs: Orders / Menu Editor / Settings
    androidx.compose.material3.TabRow(
      selectedTabIndex = adminTab,
      containerColor = Color.White,
      contentColor = DhabaRedPrimary
    ) {
      Tab(
        selected = adminTab == 0,
        onClick = { adminTab = 0 },
        text = { Text("Orders (${orders.size})", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
      )
      Tab(
        selected = adminTab == 1,
        onClick = { adminTab = 1 },
        text = { Text("Menu (${dishes.size})", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
      )
      Tab(
        selected = adminTab == 2,
        onClick = { adminTab = 2 },
        text = { Text("Settings", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
      )
    }

    when (adminTab) {
      0 -> AdminOrdersTab(
        orders = orders,
        showPrices = settings.showPrices,
        onUpdateOrderStatus = onUpdateOrderStatus,
        onNotifyCustomerWhatsApp = { order -> onNotifyCustomerWhatsApp(context, order) }
      )
      1 -> AdminMenuTab(
        dishes = dishes,
        showPrices = settings.showPrices,
        onToggleAvailability = onToggleDishAvailability,
        onUpdatePrice = onUpdateDishPrice,
        onEditDish = onSetEditingDish,
        onAddNewDish = {
          onSetEditingDish(
            DishItem(
              id = "dish_${UUID.randomUUID().toString().take(8)}",
              name = "",
              category = "SPECIAL_CHICKEN",
              description = "",
              isVeg = false,
              price = null,
              isAvailable = true
            )
          )
        }
      )
      2 -> AdminSettingsTab(
        settings = settings,
        onToggleShowPrices = onToggleShowPrices,
        onToggleForceSunday = onToggleForceSunday,
        onToggleRestaurantOpen = onToggleRestaurantOpen
      )
    }
  }

  // Edit Dish Dialog
  if (editingDish != null) {
    EditDishDialog(
      dish = editingDish,
      onDismiss = { onSetEditingDish(null) },
      onSave = onSaveDish,
      onDelete = {
        onDeleteDish(editingDish.id)
        onSetEditingDish(null)
      }
    )
  }
}

@Composable
fun AdminPinLockView(
  pin: String,
  onPinChange: (String) -> Unit,
  onUnlockClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(32.dp)
      .testTag("admin_pin_view"),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center
  ) {
    Box(
      modifier = Modifier
        .size(80.dp)
        .background(DhabaRedPrimary.copy(alpha = 0.1f), CircleShape),
      contentAlignment = Alignment.Center
    ) {
      Icon(
        imageVector = Icons.Default.Lock,
        contentDescription = null,
        tint = DhabaRedPrimary,
        modifier = Modifier.size(40.dp)
      )
    }

    Spacer(modifier = Modifier.height(20.dp))

    Text(
      text = "Ajay Dhaba Owner Access",
      style = MaterialTheme.typography.titleLarge,
      fontWeight = FontWeight.Bold
    )

    Spacer(modifier = Modifier.height(6.dp))

    Text(
      text = "Manage kitchen orders, dishes, and price settings.",
      style = MaterialTheme.typography.bodySmall,
      color = Color.Gray,
      textAlign = androidx.compose.ui.text.style.TextAlign.Center
    )

    Spacer(modifier = Modifier.height(20.dp))

    OutlinedTextField(
      value = pin,
      onValueChange = onPinChange,
      modifier = Modifier
        .fillMaxWidth()
        .testTag("admin_pin_input"),
      label = { Text("Enter 4-Digit Owner PIN") },
      placeholder = { Text("Default: 1234") },
      visualTransformation = PasswordVisualTransformation(),
      keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
      shape = RoundedCornerShape(12.dp),
      colors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = DhabaRedPrimary,
        unfocusedBorderColor = DhabaBorder
      ),
      singleLine = true
    )

    Spacer(modifier = Modifier.height(16.dp))

    Button(
      onClick = onUnlockClick,
      modifier = Modifier
        .fillMaxWidth()
        .height(50.dp)
        .testTag("admin_unlock_button"),
      colors = ButtonDefaults.buttonColors(containerColor = DhabaRedPrimary),
      shape = RoundedCornerShape(12.dp)
    ) {
      Icon(imageVector = Icons.Default.LockOpen, contentDescription = null)
      Spacer(modifier = Modifier.width(8.dp))
      Text("Unlock Dashboard", fontWeight = FontWeight.Bold)
    }

    Spacer(modifier = Modifier.height(8.dp))

    Text(
      text = "Owner PIN is 1234",
      fontSize = 11.sp,
      color = DhabaGoldDark,
      fontWeight = FontWeight.SemiBold
    )
  }
}

@Composable
fun AdminSettingsTab(
  settings: DhabaSettings,
  onToggleShowPrices: (Boolean) -> Unit,
  onToggleForceSunday: (Boolean) -> Unit,
  onToggleRestaurantOpen: (Boolean) -> Unit
) {
  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, DhabaBorder)
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
        ) {
          Text(
            text = "Customer Price Visibility Setting",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = DhabaRedPrimary
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "Per dhaba ordering rules, menu prices are hidden from customers by default. You can toggle this setting anytime without editing code.",
            style = MaterialTheme.typography.bodySmall,
            color = Color.Gray
          )

          Spacer(modifier = Modifier.height(14.dp))

          Row(
            modifier = Modifier
              .fillMaxWidth()
              .background(DhabaGoldLight.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
              .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = if (settings.showPrices) "Prices Visible to Customers" else "Prices Hidden (WhatsApp Confirmation)",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
              )
              Text(
                text = if (settings.showPrices) "Customers see dish prices and total bill" else "Customers see 'Dhaba Fresh' & confirm rates on WhatsApp",
                fontSize = 11.sp,
                color = Color.DarkGray
              )
            }

            Switch(
              checked = settings.showPrices,
              onCheckedChange = onToggleShowPrices,
              modifier = Modifier.testTag("toggle_show_prices"),
              colors = SwitchDefaults.colors(
                checkedThumbColor = DhabaRedPrimary,
                checkedTrackColor = DhabaRedContainer
              )
            )
          }
        }
      }
    }

    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, DhabaBorder)
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
        ) {
          Text(
            text = "Sunday Specials Control",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = DhabaRedPrimary
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "Sunday-only items (Mutton Handi, Mutton Curry) auto-display on Sundays. Enable this switch to showcase Sunday specials on any day.",
            style = MaterialTheme.typography.bodySmall,
            color = Color.Gray
          )

          Spacer(modifier = Modifier.height(14.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "Force Enable Sunday Specials",
              fontWeight = FontWeight.Bold,
              fontSize = 14.sp
            )

            Switch(
              checked = settings.forceSundaySpecial,
              onCheckedChange = onToggleForceSunday,
              modifier = Modifier.testTag("toggle_force_sunday"),
              colors = SwitchDefaults.colors(
                checkedThumbColor = DhabaRedPrimary,
                checkedTrackColor = DhabaRedContainer
              )
            )
          }
        }
      }
    }

    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, DhabaBorder)
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
        ) {
          Text(
            text = "Dhaba Kitchen Operation Status",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = DhabaRedPrimary
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "Controls whether the restaurant shows 'Open Now' or 'Closed' to customers.",
            style = MaterialTheme.typography.bodySmall,
            color = Color.Gray
          )

          Spacer(modifier = Modifier.height(14.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = if (settings.isRestaurantOpen) "Status: OPEN FOR ORDERS" else "Status: CURRENTLY CLOSED",
              fontWeight = FontWeight.Bold,
              fontSize = 14.sp,
              color = if (settings.isRestaurantOpen) DhabaVegGreen else Color.Red
            )

            Switch(
              checked = settings.isRestaurantOpen,
              onCheckedChange = onToggleRestaurantOpen,
              modifier = Modifier.testTag("toggle_restaurant_open"),
              colors = SwitchDefaults.colors(
                checkedThumbColor = DhabaRedPrimary,
                checkedTrackColor = DhabaRedContainer
              )
            )
          }
        }
      }
    }
  }
}

@Composable
fun AdminOrdersTab(
  orders: List<OrderRecord>,
  showPrices: Boolean,
  onUpdateOrderStatus: (String, OrderStatus) -> Unit,
  onNotifyCustomerWhatsApp: (OrderRecord) -> Unit
) {
  if (orders.isEmpty()) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(32.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center
    ) {
      Text(text = "No Customer Orders Yet", fontWeight = FontWeight.Bold)
      Text(text = "Incoming orders will appear here in real-time.", fontSize = 12.sp, color = Color.Gray)
    }
  } else {
    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      items(orders, key = { it.id }) { order ->
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = Color.White),
          border = BorderStroke(1.dp, DhabaBorder)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "Order #${order.id}",
                fontWeight = FontWeight.Black,
                color = DhabaRedPrimary
              )
              Text(
                text = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date(order.timestamp)),
                fontSize = 11.sp,
                color = Color.Gray
              )
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(text = "Customer: ${order.customerName} (${order.phone})", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text(text = "Type: ${order.orderType.displayName}", fontSize = 12.sp, color = Color.Gray)
            if (order.address.isNotBlank()) {
              Text(text = "Address: ${order.address}", fontSize = 12.sp, color = Color.Gray)
            }

            Spacer(modifier = Modifier.height(8.dp))
            HorizontalDivider(color = DhabaBorder)
            Spacer(modifier = Modifier.height(8.dp))

            order.items.forEach { item ->
              Text(text = "• ${item.quantity}x ${item.dish.name}", fontSize = 13.sp)
            }

            if (order.specialInstructions.isNotBlank()) {
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = "Note: \"${order.specialInstructions}\"",
                fontSize = 11.sp,
                color = DhabaGoldDark
              )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Status Pipeline Control
            Text(text = "Change Kitchen Status:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(6.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              OrderStatus.entries.forEach { status ->
                val isSelected = order.status == status
                Surface(
                  shape = RoundedCornerShape(8.dp),
                  color = if (isSelected) Color(status.badgeColorHex) else Color(0xFFF4F4F5),
                  modifier = Modifier
                    .weight(1f)
                    .clickable { onUpdateOrderStatus(order.id, status) }
                ) {
                  Text(
                    text = when(status) {
                      OrderStatus.RECEIVED -> "Received"
                      OrderStatus.PREPARING -> "Kitchen"
                      OrderStatus.OUT_FOR_DELIVERY -> "Delivery"
                      OrderStatus.COMPLETED -> "Done"
                      OrderStatus.CANCELLED -> "Cancel"
                    },
                    modifier = Modifier.padding(vertical = 6.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isSelected) Color.White else Color.Black
                  )
                }
              }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Button(
              onClick = { onNotifyCustomerWhatsApp(order) },
              modifier = Modifier.fillMaxWidth(),
              colors = ButtonDefaults.buttonColors(containerColor = DhabaWhatsAppGreen),
              shape = RoundedCornerShape(8.dp)
            ) {
              Icon(imageVector = Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(14.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("Send Status Update via WhatsApp", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    }
  }
}

@Composable
fun AdminMenuTab(
  dishes: List<DishItem>,
  showPrices: Boolean,
  onToggleAvailability: (String, Boolean) -> Unit,
  onUpdatePrice: (String, Double?) -> Unit,
  onEditDish: (DishItem) -> Unit,
  onAddNewDish: () -> Unit
) {
  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 90.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "Menu Items (${dishes.size})",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold
        )

        Button(
          onClick = onAddNewDish,
          colors = ButtonDefaults.buttonColors(containerColor = DhabaRedPrimary),
          shape = RoundedCornerShape(10.dp)
        ) {
          Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("Add Dish", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
      }
    }

    items(dishes, key = { it.id }) { dish ->
      var isEditingPrice by remember { mutableStateOf(false) }
      var priceInput by remember(dish.price) { mutableStateOf(dish.price?.toInt()?.toString() ?: "") }

      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, DhabaBorder)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.weight(1f)
            ) {
              VegBadge(isVeg = dish.isVeg)
              Spacer(modifier = Modifier.width(8.dp))
              Column {
                Text(text = dish.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(text = dish.category, fontSize = 11.sp, color = Color.Gray)
              }
            }

            IconButton(onClick = { onEditDish(dish) }) {
              Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit Dish", tint = DhabaRedPrimary)
            }
          }

          Spacer(modifier = Modifier.height(8.dp))

          // Price & Availability Quick Toggles
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            // Price editing
            if (isEditingPrice) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                  value = priceInput,
                  onValueChange = { priceInput = it },
                  modifier = Modifier.width(80.dp),
                  placeholder = { Text("₹") },
                  keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                  singleLine = true
                )
                IconButton(onClick = {
                  val newPrice = priceInput.toDoubleOrNull()
                  onUpdatePrice(dish.id, newPrice)
                  isEditingPrice = false
                }) {
                  Icon(imageVector = Icons.Default.Check, contentDescription = "Save", tint = DhabaVegGreen)
                }
              }
            } else {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.clickable { isEditingPrice = true }
              ) {
                Text(
                  text = if (dish.price != null && dish.price > 0) "Price: ₹${dish.price.toInt()}" else "Price: Not Set",
                  fontSize = 13.sp,
                  fontWeight = FontWeight.Bold,
                  color = DhabaRedPrimary
                )
                Spacer(modifier = Modifier.width(4.dp))
                Icon(imageVector = Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(12.dp), tint = Color.Gray)
              }
            }

            // In Stock / Sold Out switch
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(
                text = if (dish.isAvailable) "Available" else "Sold Out",
                fontSize = 12.sp,
                color = if (dish.isAvailable) DhabaVegGreen else Color.Red,
                fontWeight = FontWeight.SemiBold
              )
              Spacer(modifier = Modifier.width(6.dp))
              Switch(
                checked = dish.isAvailable,
                onCheckedChange = { onToggleAvailability(dish.id, dish.isAvailable) },
                colors = SwitchDefaults.colors(
                  checkedThumbColor = DhabaVegGreen,
                  checkedTrackColor = DhabaVegGreen.copy(alpha = 0.3f)
                )
              )
            }
          }
        }
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditDishDialog(
  dish: DishItem,
  onDismiss: () -> Unit,
  onSave: (DishItem) -> Unit,
  onDelete: () -> Unit
) {
  var name by remember { mutableStateOf(dish.name) }
  var category by remember { mutableStateOf(dish.category) }
  var description by remember { mutableStateOf(dish.description) }
  var isVeg by remember { mutableStateOf(dish.isVeg) }
  var priceStr by remember { mutableStateOf(dish.price?.toInt()?.toString() ?: "") }
  var isSundayOnly by remember { mutableStateOf(dish.isSundayOnly) }
  var isAvailable by remember { mutableStateOf(dish.isAvailable) }
  var isSpecial by remember { mutableStateOf(dish.isSpecial) }

  var expandedCategory by remember { mutableStateOf(false) }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Text(
        text = if (dish.name.isBlank()) "Add New Dhaba Dish" else "Edit Dish: ${dish.name}",
        fontWeight = FontWeight.Bold,
        fontSize = 16.sp
      )
    },
    text = {
      LazyColumn(
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        item {
          OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("Dish Name") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
          )
        }

        item {
          ExposedDropdownMenuBox(
            expanded = expandedCategory,
            onExpandedChange = { expandedCategory = !expandedCategory }
          ) {
            OutlinedTextField(
              value = category,
              onValueChange = {},
              readOnly = true,
              label = { Text("Category") },
              trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedCategory) },
              modifier = Modifier
                .menuAnchor()
                .fillMaxWidth()
            )
            ExposedDropdownMenu(
              expanded = expandedCategory,
              onDismissRequest = { expandedCategory = false }
            ) {
              MenuCategory.entries.forEach { cat ->
                DropdownMenuItem(
                  text = { Text(cat.displayName) },
                  onClick = {
                    category = cat.name
                    expandedCategory = false
                  }
                )
              }
            }
          }
        }

        item {
          OutlinedTextField(
            value = description,
            onValueChange = { description = it },
            label = { Text("Description & Ingredients") },
            modifier = Modifier.fillMaxWidth(),
            maxLines = 3
          )
        }

        item {
          OutlinedTextField(
            value = priceStr,
            onValueChange = { priceStr = it },
            label = { Text("Dish Price (₹) - Leave blank if hidden") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
          )
        }

        item {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(text = "Pure Vegetarian", fontSize = 13.sp)
            Switch(checked = isVeg, onCheckedChange = { isVeg = it })
          }
        }

        item {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(text = "Sunday Only Handi Dish", fontSize = 13.sp)
            Switch(checked = isSundayOnly, onCheckedChange = { isSundayOnly = it })
          }
        }

        item {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(text = "Available in Kitchen", fontSize = 13.sp)
            Switch(checked = isAvailable, onCheckedChange = { isAvailable = it })
          }
        }

        item {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(text = "Mark as Today's Special", fontSize = 13.sp)
            Switch(checked = isSpecial, onCheckedChange = { isSpecial = it })
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          if (name.isNotBlank()) {
            val updated = dish.copy(
              name = name.trim(),
              category = category,
              description = description.trim(),
              isVeg = isVeg,
              price = priceStr.toDoubleOrNull(),
              isSundayOnly = isSundayOnly,
              isAvailable = isAvailable,
              isSpecial = isSpecial
            )
            onSave(updated)
          }
        },
        colors = ButtonDefaults.buttonColors(containerColor = DhabaRedPrimary)
      ) {
        Text("Save Dish")
      }
    },
    dismissButton = {
      Row {
        if (dish.id.isNotBlank()) {
          TextButton(
            onClick = onDelete,
            colors = ButtonDefaults.textButtonColors(contentColor = Color.Red)
          ) {
            Text("Delete")
          }
        }
        TextButton(onClick = onDismiss) {
          Text("Cancel")
        }
      }
    }
  )
}
