package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.RestaurantMenu
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.outlined.AdminPanelSettings
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material.icons.outlined.RestaurantMenu
import androidx.compose.material.icons.outlined.ShoppingCart
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.AppScreen
import com.example.ui.theme.DhabaBorder
import com.example.ui.theme.DhabaGold
import com.example.ui.theme.DhabaRedContainer
import com.example.ui.theme.DhabaRedPrimary

@Composable
fun DhabaBottomNav(
  currentScreen: AppScreen,
  cartItemCount: Int,
  onScreenSelected: (AppScreen) -> Unit,
  modifier: Modifier = Modifier
) {
  Box(
    modifier = modifier
      .fillMaxWidth()
      .background(Color.White)
      .windowInsetsPadding(WindowInsets.navigationBars)
  ) {
    NavigationBar(
      modifier = Modifier.fillMaxWidth(),
      containerColor = Color.White,
      tonalElevation = 8.dp
    ) {
      val items = listOf(
        Triple(AppScreen.HOME, Icons.Filled.Home, Icons.Outlined.Home),
        Triple(AppScreen.MENU, Icons.Filled.RestaurantMenu, Icons.Outlined.RestaurantMenu),
        Triple(AppScreen.CART, Icons.Filled.ShoppingCart, Icons.Outlined.ShoppingCart),
        Triple(AppScreen.ORDERS, Icons.Filled.ReceiptLong, Icons.Outlined.ReceiptLong),
        Triple(AppScreen.ADMIN, Icons.Filled.AdminPanelSettings, Icons.Outlined.AdminPanelSettings)
      )

      items.forEach { (screen, filledIcon, outlinedIcon) ->
        val selected = currentScreen == screen

        NavigationBarItem(
          selected = selected,
          onClick = { onScreenSelected(screen) },
          modifier = Modifier.testTag("nav_tab_${screen.name.lowercase()}"),
          icon = {
            if (screen == AppScreen.CART && cartItemCount > 0) {
              BadgedBox(
                badge = {
                  Badge(
                    containerColor = DhabaRedPrimary,
                    contentColor = Color.White
                  ) {
                    Text(text = "$cartItemCount", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                  }
                }
              ) {
                Icon(
                  imageVector = if (selected) filledIcon else outlinedIcon,
                  contentDescription = screen.title
                )
              }
            } else {
              Icon(
                imageVector = if (selected) filledIcon else outlinedIcon,
                contentDescription = screen.title
              )
            }
          },
          label = {
            Text(
              text = screen.title,
              fontSize = 11.sp,
              fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
            )
          },
          colors = NavigationBarItemDefaults.colors(
            selectedIconColor = DhabaRedPrimary,
            selectedTextColor = DhabaRedPrimary,
            indicatorColor = DhabaRedContainer,
            unselectedIconColor = Color(0xFF71717A),
            unselectedTextColor = Color(0xFF71717A)
          )
        )
      }
    }
  }
}
