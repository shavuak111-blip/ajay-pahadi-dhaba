package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeliveryDining
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DividerDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CartItem
import com.example.data.model.OrderRecord
import com.example.data.model.OrderType
import com.example.data.repository.DhabaRepository
import com.example.ui.components.VegBadge
import com.example.ui.theme.DhabaBorder
import com.example.ui.theme.DhabaCharcoal
import com.example.ui.theme.DhabaGold
import com.example.ui.theme.DhabaGoldDark
import com.example.ui.theme.DhabaGoldLight
import com.example.ui.theme.DhabaRedPrimary
import com.example.ui.theme.DhabaVegGreen
import com.example.ui.theme.DhabaWhatsAppGreen

@Composable
fun CartScreen(
  cartItems: List<CartItem>,
  customerName: String,
  customerPhone: String,
  deliveryAddress: String,
  orderType: OrderType,
  specialInstructions: String,
  showPrices: Boolean,
  lastPlacedOrder: OrderRecord?,
  onUpdateQuantity: (String, Int) -> Unit,
  onRemoveItem: (String) -> Unit,
  onCustomerNameChange: (String) -> Unit,
  onCustomerPhoneChange: (String) -> Unit,
  onDeliveryAddressChange: (String) -> Unit,
  onOrderTypeChange: (OrderType) -> Unit,
  onSpecialInstructionsChange: (String) -> Unit,
  onPlaceWhatsAppOrder: (Context) -> Unit,
  onPlaceOnlineOrder: () -> Unit,
  onStartNewOrder: () -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current

  // If order was just placed, show confirmation screen
  if (lastPlacedOrder != null) {
    OrderSuccessView(
      order = lastPlacedOrder,
      showPrices = showPrices,
      onSendToWhatsApp = { onPlaceWhatsAppOrder(context) },
      onStartNewOrder = onStartNewOrder,
      modifier = modifier
    )
    return
  }

  if (cartItems.isEmpty()) {
    EmptyCartView(modifier = modifier)
    return
  }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .testTag("cart_screen_content"),
    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 100.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // 1. Cart Items List Card
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, DhabaBorder)
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "Selected Dishes (${cartItems.sumOf { it.quantity }})",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = DhabaRedPrimary
            )
            Text(
              text = DhabaRepository.RESTAURANT_NAME,
              style = MaterialTheme.typography.bodySmall,
              color = Color.Gray
            )
          }

          Spacer(modifier = Modifier.height(12.dp))

          cartItems.forEachIndexed { index, item ->
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              VegBadge(isVeg = item.dish.isVeg)
              Spacer(modifier = Modifier.width(8.dp))

              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = item.dish.name,
                  fontWeight = FontWeight.Bold,
                  fontSize = 14.sp
                )
                if (showPrices && item.dish.price != null && item.dish.price > 0) {
                  Text(
                    text = "₹${item.dish.price.toInt()} each",
                    fontSize = 12.sp,
                    color = DhabaRedPrimary
                  )
                }
              }

              // Quantity Selector
              Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                  .background(Color(0xFFF4F4F5), RoundedCornerShape(8.dp))
                  .padding(horizontal = 4.dp, vertical = 2.dp)
              ) {
                IconButton(
                  onClick = { onUpdateQuantity(item.dish.id, item.quantity - 1) },
                  modifier = Modifier.size(28.dp)
                ) {
                  Icon(
                    imageVector = if (item.quantity == 1) Icons.Default.Delete else Icons.Default.Remove,
                    contentDescription = "Decrease",
                    tint = DhabaRedPrimary,
                    modifier = Modifier.size(15.dp)
                  )
                }

                Text(
                  text = "${item.quantity}",
                  fontWeight = FontWeight.Bold,
                  fontSize = 13.sp,
                  modifier = Modifier.padding(horizontal = 6.dp)
                )

                IconButton(
                  onClick = { onUpdateQuantity(item.dish.id, item.quantity + 1) },
                  modifier = Modifier.size(28.dp)
                ) {
                  Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Increase",
                    tint = DhabaRedPrimary,
                    modifier = Modifier.size(15.dp)
                  )
                }
              }
            }

            if (index < cartItems.size - 1) {
              HorizontalDivider(color = DhabaBorder.copy(alpha = 0.5f), thickness = 0.5.dp)
            }
          }
        }
      }
    }

    // 2. Special Cooking Instructions
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, DhabaBorder)
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.EditNote,
              contentDescription = null,
              tint = DhabaGoldDark,
              modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "Cooking & Packaging Notes",
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.Bold
            )
          }

          Spacer(modifier = Modifier.height(8.dp))

          OutlinedTextField(
            value = specialInstructions,
            onValueChange = onSpecialInstructionsChange,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("cart_special_instructions"),
            placeholder = {
              Text(
                "E.g., Extra green chutney, less spicy gravy, butter crisp on rotis...",
                fontSize = 13.sp,
                color = Color.Gray
              )
            },
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = DhabaRedPrimary,
              unfocusedBorderColor = DhabaBorder
            ),
            maxLines = 3
          )
        }
      }
    }

    // 3. Delivery or Pickup Selection
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, DhabaBorder)
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
        ) {
          Text(
            text = "Order Delivery Method",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = DhabaRedPrimary
          )

          Spacer(modifier = Modifier.height(10.dp))

          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(10.dp))
              .background(if (orderType == OrderType.DELIVERY) DhabaRedPrimary.copy(alpha = 0.08f) else Color.Transparent)
              .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            RadioButton(
              selected = orderType == OrderType.DELIVERY,
              onClick = { onOrderTypeChange(OrderType.DELIVERY) },
              colors = RadioButtonDefaults.colors(selectedColor = DhabaRedPrimary)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Column {
              Text(
                text = "Doorstep Delivery (0–3 km)",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
              )
              Text(
                text = "Free delivery within 3 km of Ajay Pahadi Dhaba",
                fontSize = 11.sp,
                color = DhabaVegGreen,
                fontWeight = FontWeight.SemiBold
              )
            }
          }

          Spacer(modifier = Modifier.height(6.dp))

          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(10.dp))
              .background(if (orderType == OrderType.PICKUP) DhabaRedPrimary.copy(alpha = 0.08f) else Color.Transparent)
              .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            RadioButton(
              selected = orderType == OrderType.PICKUP,
              onClick = { onOrderTypeChange(OrderType.PICKUP) },
              colors = RadioButtonDefaults.colors(selectedColor = DhabaRedPrimary)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Column {
              Text(
                text = "Self Pickup / Takeaway",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
              )
              Text(
                text = "Collect directly from counter in Himachal Pradesh",
                fontSize = 11.sp,
                color = Color.Gray
              )
            }
          }
        }
      }
    }

    // 4. Customer Details Form
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, DhabaBorder)
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
        ) {
          Text(
            text = "Customer Details",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = DhabaRedPrimary
          )

          Spacer(modifier = Modifier.height(12.dp))

          OutlinedTextField(
            value = customerName,
            onValueChange = onCustomerNameChange,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("cart_customer_name"),
            label = { Text("Your Full Name") },
            leadingIcon = {
              Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = DhabaRedPrimary)
            },
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = DhabaRedPrimary,
              unfocusedBorderColor = DhabaBorder
            ),
            singleLine = true
          )

          Spacer(modifier = Modifier.height(10.dp))

          OutlinedTextField(
            value = customerPhone,
            onValueChange = onCustomerPhoneChange,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("cart_customer_phone"),
            label = { Text("Mobile Number (WhatsApp)") },
            leadingIcon = {
              Icon(imageVector = Icons.Default.Phone, contentDescription = null, tint = DhabaRedPrimary)
            },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = DhabaRedPrimary,
              unfocusedBorderColor = DhabaBorder
            ),
            singleLine = true
          )

          if (orderType == OrderType.DELIVERY) {
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(
              value = deliveryAddress,
              onValueChange = onDeliveryAddressChange,
              modifier = Modifier
                .fillMaxWidth()
                .testTag("cart_delivery_address"),
              label = { Text("Delivery Address (within 0–3 km)") },
              placeholder = { Text("House/Room No., Street, Landmark in Himachal Pradesh") },
              leadingIcon = {
                Icon(imageVector = Icons.Default.LocationOn, contentDescription = null, tint = DhabaRedPrimary)
              },
              shape = RoundedCornerShape(12.dp),
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = DhabaRedPrimary,
                unfocusedBorderColor = DhabaBorder
              ),
              maxLines = 3
            )
          }
        }
      }
    }

    // 5. Order Summary & Total
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, DhabaBorder)
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.Receipt,
              contentDescription = null,
              tint = DhabaRedPrimary,
              modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "Order Bill Summary",
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.Bold
            )
          }

          Spacer(modifier = Modifier.height(10.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(text = "Total Items", fontSize = 13.sp, color = Color.Gray)
            Text(
              text = "${cartItems.sumOf { it.quantity }} items",
              fontSize = 13.sp,
              fontWeight = FontWeight.SemiBold
            )
          }

          Spacer(modifier = Modifier.height(6.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(text = "Delivery Charges (0–3 km)", fontSize = 13.sp, color = Color.Gray)
            Text(
              text = "FREE",
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold,
              color = DhabaVegGreen
            )
          }

          Spacer(modifier = Modifier.height(10.dp))
          HorizontalDivider(color = DhabaBorder)
          Spacer(modifier = Modifier.height(10.dp))

          // Rule check: Never calculate a fake final total when prices are not configured
          var allPriced = true
          var calculatedSum = 0.0
          for (item in cartItems) {
            if (item.dish.price != null && item.dish.price > 0) {
              calculatedSum += item.dish.price * item.quantity
            } else {
              allPriced = false
              break
            }
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "Final Total",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold
            )

            if (showPrices && allPriced) {
              Text(
                text = "₹${calculatedSum.toInt()}",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Black,
                color = DhabaRedPrimary
              )
            } else {
              Column(horizontalAlignment = Alignment.End) {
                Text(
                  text = "Confirmed on WhatsApp",
                  style = MaterialTheme.typography.titleSmall,
                  fontWeight = FontWeight.Bold,
                  color = DhabaGoldDark
                )
                Text(
                  text = "Authentic daily dhaba rates",
                  fontSize = 10.sp,
                  color = Color.Gray
                )
              }
            }
          }
        }
      }
    }

    // 6. Dual Ordering Methods (WhatsApp & Online Database Storage)
    item {
      Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        // WhatsApp Ordering Button (Primary Fallback)
        Button(
          onClick = { onPlaceWhatsAppOrder(context) },
          modifier = Modifier
            .fillMaxWidth()
            .height(54.dp)
            .testTag("whatsapp_order_button"),
          colors = ButtonDefaults.buttonColors(
            containerColor = DhabaWhatsAppGreen,
            contentColor = Color.White
          ),
          shape = RoundedCornerShape(14.dp)
        ) {
          Icon(
            imageVector = Icons.Default.Chat,
            contentDescription = "WhatsApp",
            modifier = Modifier.size(20.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "Send Order via WhatsApp",
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp
          )
        }

        // Online Storage Order Button
        OutlinedButton(
          onClick = onPlaceOnlineOrder,
          modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
            .testTag("online_order_button"),
          colors = ButtonDefaults.outlinedButtonColors(
            contentColor = DhabaRedPrimary
          ),
          border = BorderStroke(1.5.dp, DhabaRedPrimary),
          shape = RoundedCornerShape(14.dp)
        ) {
          Icon(
            imageVector = Icons.Default.CheckCircle,
            contentDescription = null,
            tint = DhabaRedPrimary,
            modifier = Modifier.size(18.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "Save & Confirm Online Order",
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp
          )
        }

        Text(
          text = "Orders are securely saved in restaurant records. WhatsApp opens ready with your customized message for instant confirmation from the kitchen.",
          style = MaterialTheme.typography.bodySmall,
          color = Color.Gray,
          fontSize = 11.sp,
          modifier = Modifier.padding(horizontal = 4.dp)
        )
      }
    }
  }
}

@Composable
fun OrderSuccessView(
  order: OrderRecord,
  showPrices: Boolean,
  onSendToWhatsApp: () -> Unit,
  onStartNewOrder: () -> Unit,
  modifier: Modifier = Modifier
) {
  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(24.dp)
      .testTag("order_success_view"),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center
  ) {
    Box(
      modifier = Modifier
        .size(80.dp)
        .background(DhabaVegGreen.copy(alpha = 0.15f), CircleShape),
      contentAlignment = Alignment.Center
    ) {
      Icon(
        imageVector = Icons.Default.CheckCircle,
        contentDescription = null,
        tint = DhabaVegGreen,
        modifier = Modifier.size(50.dp)
      )
    }

    Spacer(modifier = Modifier.height(16.dp))

    Text(
      text = "Order Placed Successfully!",
      style = MaterialTheme.typography.headlineSmall,
      fontWeight = FontWeight.Black,
      color = DhabaCharcoal
    )

    Spacer(modifier = Modifier.height(6.dp))

    Surface(
      color = DhabaGoldLight,
      shape = RoundedCornerShape(8.dp)
    ) {
      Text(
        text = "ORDER ID: #${order.id}",
        fontWeight = FontWeight.Bold,
        fontSize = 14.sp,
        color = DhabaGoldDark,
        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
      )
    }

    Spacer(modifier = Modifier.height(16.dp))

    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = Color.White),
      border = BorderStroke(1.dp, DhabaBorder)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(16.dp)
      ) {
        Text(
          text = "Order Details",
          fontWeight = FontWeight.Bold,
          color = DhabaRedPrimary
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(text = "Customer: ${order.customerName}", fontSize = 13.sp)
        Text(text = "Mobile: ${order.phone}", fontSize = 13.sp)
        Text(text = "Type: ${order.orderType.displayName}", fontSize = 13.sp)
        if (order.orderType == OrderType.DELIVERY) {
          Text(text = "Address: ${order.address}", fontSize = 13.sp)
        }

        Spacer(modifier = Modifier.height(8.dp))
        HorizontalDivider(color = DhabaBorder)
        Spacer(modifier = Modifier.height(8.dp))

        order.items.forEach { item ->
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(text = "${item.quantity}x ${item.dish.name}", fontSize = 13.sp)
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(20.dp))

    Button(
      onClick = onSendToWhatsApp,
      modifier = Modifier
        .fillMaxWidth()
        .height(52.dp),
      colors = ButtonDefaults.buttonColors(containerColor = DhabaWhatsAppGreen),
      shape = RoundedCornerShape(14.dp)
    ) {
      Icon(imageVector = Icons.Default.Chat, contentDescription = null, tint = Color.White)
      Spacer(modifier = Modifier.width(8.dp))
      Text("Send Receipt on WhatsApp", fontWeight = FontWeight.Bold)
    }

    Spacer(modifier = Modifier.height(10.dp))

    OutlinedButton(
      onClick = onStartNewOrder,
      modifier = Modifier
        .fillMaxWidth()
        .height(48.dp),
      shape = RoundedCornerShape(14.dp)
    ) {
      Text("Order More Dishes", fontWeight = FontWeight.SemiBold)
    }
  }
}

@Composable
fun EmptyCartView(modifier: Modifier = Modifier) {
  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(32.dp)
      .testTag("empty_cart_view"),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center
  ) {
    Box(
      modifier = Modifier
        .size(90.dp)
        .background(DhabaRedPrimary.copy(alpha = 0.1f), CircleShape),
      contentAlignment = Alignment.Center
    ) {
      Icon(
        imageVector = Icons.Default.ShoppingCart,
        contentDescription = null,
        tint = DhabaRedPrimary,
        modifier = Modifier.size(46.dp)
      )
    }

    Spacer(modifier = Modifier.height(20.dp))

    Text(
      text = "Your Dhaba Cart is Empty",
      style = MaterialTheme.typography.titleLarge,
      fontWeight = FontWeight.Bold
    )

    Spacer(modifier = Modifier.height(6.dp))

    Text(
      text = "Explore our Special Tawa Chicken, fresh paranthas, and authentic pahadi meals to start ordering.",
      style = MaterialTheme.typography.bodyMedium,
      color = Color.Gray,
      textAlign = androidx.compose.ui.text.style.TextAlign.Center
    )
  }
}
