package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DhabaLightColorScheme = lightColorScheme(
  primary = DhabaRedPrimary,
  onPrimary = Color.White,
  primaryContainer = DhabaRedContainer,
  onPrimaryContainer = DhabaOnRedContainer,
  secondary = DhabaCharcoal,
  onSecondary = Color.White,
  secondaryContainer = DhabaGoldLight,
  onSecondaryContainer = DhabaCharcoal,
  tertiary = DhabaGoldDark,
  onTertiary = Color.White,
  tertiaryContainer = DhabaGoldLight,
  onTertiaryContainer = DhabaCharcoal,
  background = DhabaCreamBg,
  onBackground = DhabaCharcoal,
  surface = DhabaCreamSurface,
  onSurface = DhabaCharcoal,
  surfaceVariant = DhabaCreamCard,
  onSurfaceVariant = DhabaCharcoal,
  outline = DhabaBorder,
  outlineVariant = Color(0xFFE2DCD2)
)

private val DhabaDarkColorScheme = darkColorScheme(
  primary = DhabaRedLight,
  onPrimary = Color.White,
  primaryContainer = DhabaRedDark,
  onPrimaryContainer = DhabaGoldLight,
  secondary = DhabaGoldBright,
  onSecondary = DhabaCharcoal,
  secondaryContainer = Color(0xFF27272A),
  onSecondaryContainer = Color.White,
  tertiary = DhabaGold,
  onTertiary = Color.Black,
  background = Color(0xFF121212),
  onBackground = Color(0xFFF4F4F5),
  surface = Color(0xFF1E1E20),
  onSurface = Color(0xFFF4F4F5),
  surfaceVariant = Color(0xFF27272A),
  onSurfaceVariant = Color(0xFFE4E4E7),
  outline = Color(0xFF3F3F46)
)

@Composable
fun DhabaTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  content: @Composable () -> Unit,
) {
  // Use our curated Dhaba color scheme for authentic brand styling
  val colorScheme = if (darkTheme) DhabaDarkColorScheme else DhabaLightColorScheme

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content
  )
}
