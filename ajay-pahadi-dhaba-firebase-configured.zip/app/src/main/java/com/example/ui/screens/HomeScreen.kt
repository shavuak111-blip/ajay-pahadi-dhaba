package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CartItem
import com.example.data.model.DishItem
import com.example.data.model.MealFilter
import com.example.data.model.MenuCategory
import com.example.data.repository.DhabaRepository
import com.example.ui.components.DeliveryInfoBanner
import com.example.ui.components.DishCard
import com.example.ui.components.HeroBanner
import com.example.ui.theme.DhabaBorder
import com.example.ui.theme.DhabaCharcoal
import com.example.ui.theme.DhabaGold
import com.example.ui.theme.DhabaGoldDark
import com.example.ui.theme.DhabaGoldLight
import com.example.ui.theme.DhabaRedContainer
import com.example.ui.theme.DhabaRedPrimary
import com.example.ui.theme.DhabaVegGreen
import com.example.ui.theme.DhabaWhatsAppGreen

@Composable
fun HomeScreen(
  dishes: List<DishItem>,
  allDishes: List<DishItem>,
  cartItems: List<CartItem>,
  showPrices: Boolean,
  searchQuery: String,
  selectedCategory: MenuCategory?,
  selectedMealFilter: MealFilter,
  onlyVegFilter: Boolean,
  onSearchChange: (String) -> Unit,
  onCategorySelect: (MenuCategory?) -> Unit,
  onMealFilterSelect: (MealFilter) -> Unit,
  onToggleVeg: () -> Unit,
  onAddToCart: (DishItem) -> Unit,
  onUpdateQuantity: (String, Int) -> Unit,
  onWhatsAppQuickOrder: () -> Unit,
  modifier: Modifier = Modifier
) {
  val tawaChickenDish = allDishes.find { it.id == "tawa_chicken" }
  val specials = dishes.filter { it.isSpecial }
  val popularDishes = dishes.filter { it.isPopular }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .testTag("home_screen_content"),
    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 90.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // 1. Search Bar
    item {
      OutlinedTextField(
        value = searchQuery,
        onValueChange = onSearchChange,
        modifier = Modifier
          .fillMaxWidth()
          .testTag("home_search_bar"),
        placeholder = {
          Text(
            text = "Search Tawa Chicken, Rajma, Paranthas...",
            fontSize = 14.sp,
            color = Color.Gray
          )
        },
        leadingIcon = {
          Icon(
            imageVector = Icons.Default.Search,
            contentDescription = "Search",
            tint = DhabaRedPrimary
          )
        },
        trailingIcon = {
          if (searchQuery.isNotEmpty()) {
            IconButton(onClick = { onSearchChange("") }) {
              Icon(
                imageVector = Icons.Default.Clear,
                contentDescription = "Clear search",
                tint = Color.Gray
              )
            }
          }
        },
        shape = RoundedCornerShape(16.dp),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = DhabaRedPrimary,
          unfocusedBorderColor = DhabaBorder,
          focusedContainerColor = Color.White,
          unfocusedContainerColor = Color.White
        ),
        singleLine = true
      )
    }

    // 2. Hero Banner (Special Tawa Chicken)
    item {
      HeroBanner(
        tawaChickenDish = tawaChickenDish,
        showPrice = showPrices,
        onOrderNow = onAddToCart
      )
    }

    // 3. Free Delivery Banner (0-3 km) & WhatsApp Quick Order
    item {
      DeliveryInfoBanner(
        onWhatsAppQuickOrder = onWhatsAppQuickOrder
      )
    }

    // 4. Meal Time Selector (Breakfast, Lunch, Dinner, All)
    item {
      Column {
        Text(
          text = "Meal Timings",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          MealFilter.entries.forEach { meal ->
            val isSelected = selectedMealFilter == meal
            FilterChip(
              selected = isSelected,
              onClick = { onMealFilterSelect(meal) },
              label = {
                Text(
                  text = meal.label,
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                  fontSize = 13.sp
                )
              },
              colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = DhabaRedPrimary,
                selectedLabelColor = Color.White,
                containerColor = Color.White,
                labelColor = MaterialTheme.colorScheme.onSurface
              ),
              border = FilterChipDefaults.filterChipBorder(
                borderColor = if (isSelected) DhabaRedPrimary else DhabaBorder,
                selectedBorderColor = DhabaRedPrimary,
                enabled = true,
                selected = isSelected
              ),
              shape = RoundedCornerShape(20.dp)
            )
          }

          // Veg Only toggle
          FilterChip(
            selected = onlyVegFilter,
            onClick = onToggleVeg,
            label = {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                  modifier = Modifier
                    .size(8.dp)
                    .background(DhabaVegGreen, CircleShape)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = "Pure Veg Only",
                  fontWeight = if (onlyVegFilter) FontWeight.Bold else FontWeight.Normal,
                  fontSize = 13.sp
                )
              }
            },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = DhabaVegGreen,
              selectedLabelColor = Color.White,
              containerColor = Color.White,
              labelColor = MaterialTheme.colorScheme.onSurface
            ),
            border = FilterChipDefaults.filterChipBorder(
              borderColor = if (onlyVegFilter) DhabaVegGreen else DhabaBorder,
              selectedBorderColor = DhabaVegGreen,
              enabled = true,
              selected = onlyVegFilter
            ),
            shape = RoundedCornerShape(20.dp)
          )
        }
      }
    }

    // 5. Menu Categories Horizontal Carousel
    item {
      Column {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "Menu Categories",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )
          if (selectedCategory != null) {
            Text(
              text = "Clear filter",
              style = MaterialTheme.typography.bodySmall,
              color = DhabaRedPrimary,
              fontWeight = FontWeight.SemiBold,
              modifier = Modifier.clickable { onCategorySelect(null) }
            )
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
          modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          MenuCategory.entries.forEach { category ->
            val isSelected = selectedCategory == category
            Surface(
              shape = RoundedCornerShape(12.dp),
              color = if (isSelected) DhabaRedPrimary else Color.White,
              border = BorderStroke(1.dp, if (isSelected) DhabaRedPrimary else DhabaBorder),
              modifier = Modifier
                .clickable { onCategorySelect(category) }
                .testTag("category_chip_${category.name.lowercase()}")
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = category.displayName,
                  color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                  fontSize = 13.sp
                )
              }
            }
          }
        }
      }
    }

    // 6. Today's Specials Header & List
    if (specials.isNotEmpty() && searchQuery.isBlank() && selectedCategory == null) {
      item {
        Row(
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(
            imageVector = Icons.Default.Star,
            contentDescription = null,
            tint = DhabaGoldDark,
            modifier = Modifier.size(18.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "Today's Specials",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )
        }
      }

      items(specials.take(3), key = { "special_${it.id}" }) { dish ->
        val cartItem = cartItems.find { it.dish.id == dish.id }
        DishCard(
          dish = dish,
          cartItem = cartItem,
          showPrice = showPrices,
          onAddToCart = onAddToCart,
          onUpdateQuantity = onUpdateQuantity
        )
      }
    }

    // 7. Popular Dishes / All Dishes Header
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Default.LocalFireDepartment,
            contentDescription = null,
            tint = DhabaRedPrimary,
            modifier = Modifier.size(20.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = if (selectedCategory != null) selectedCategory.displayName else "All Pahadi Dishes",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )
        }

        Text(
          text = "${dishes.size} items",
          style = MaterialTheme.typography.bodySmall,
          color = Color.Gray
        )
      }
    }

    // 8. Dishes List
    if (dishes.isEmpty()) {
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = Color.White),
          border = BorderStroke(1.dp, DhabaBorder)
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Icon(
              imageVector = Icons.Default.Restaurant,
              contentDescription = null,
              tint = DhabaGoldDark,
              modifier = Modifier.size(48.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
              text = "No dishes match your filter",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = "Try clearing search or choosing another category.",
              style = MaterialTheme.typography.bodySmall,
              color = Color.Gray
            )
          }
        }
      }
    } else {
      items(dishes, key = { it.id }) { dish ->
        val cartItem = cartItems.find { it.dish.id == dish.id }
        DishCard(
          dish = dish,
          cartItem = cartItem,
          showPrice = showPrices,
          onAddToCart = onAddToCart,
          onUpdateQuantity = onUpdateQuantity
        )
      }
    }

    // 9. Authentic Dhaba Info & Location Card
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
          containerColor = MaterialTheme.colorScheme.surface
        ),
        border = BorderStroke(1.dp, DhabaBorder)
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
        ) {
          Text(
            text = "About ${DhabaRepository.RESTAURANT_NAME}",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = DhabaRedPrimary
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "Traditional highway dhaba serving breakfast, lunch, dinner, authentic chicken dishes, wholesome thalis, paranthas, and fresh pahadi chai. Prepared with pure local ingredients and authentic mountain recipes.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
          )

          Spacer(modifier = Modifier.height(12.dp))

          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.LocationOn,
              contentDescription = null,
              tint = DhabaRedPrimary,
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = DhabaRepository.RESTAURANT_LOCATION,
              style = MaterialTheme.typography.bodySmall,
              fontWeight = FontWeight.SemiBold
            )
          }

          Spacer(modifier = Modifier.height(6.dp))

          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.Chat,
              contentDescription = null,
              tint = DhabaWhatsAppGreen,
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "Phone & WhatsApp: ${DhabaRepository.RESTAURANT_PHONE}",
              style = MaterialTheme.typography.bodySmall,
              fontWeight = FontWeight.SemiBold
            )
          }
        }
      }
    }
  }
}
