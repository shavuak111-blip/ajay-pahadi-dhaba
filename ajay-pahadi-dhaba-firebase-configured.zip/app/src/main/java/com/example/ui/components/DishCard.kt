package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CartItem
import com.example.data.model.DishItem
import com.example.ui.theme.DhabaBorder
import com.example.ui.theme.DhabaGold
import com.example.ui.theme.DhabaGoldDark
import com.example.ui.theme.DhabaNonVegRed
import com.example.ui.theme.DhabaRedPrimary
import com.example.ui.theme.DhabaSundayPurple
import com.example.ui.theme.DhabaVegGreen

@Composable
fun DishCard(
  dish: DishItem,
  cartItem: CartItem?,
  showPrice: Boolean,
  onAddToCart: (DishItem) -> Unit,
  onUpdateQuantity: (String, Int) -> Unit,
  modifier: Modifier = Modifier
) {
  Card(
    modifier = modifier
      .fillMaxWidth()
      .testTag("dish_card_${dish.id}"),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.surface
    ),
    border = BorderStroke(1.dp, DhabaBorder),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      // Dish visual illustration
      Box(
        modifier = Modifier
          .size(86.dp)
          .clip(RoundedCornerShape(14.dp))
      ) {
        DishIllustration(
          imageIdentifier = dish.imageIdentifier,
          category = dish.category,
          isVeg = dish.isVeg,
          modifier = Modifier.size(86.dp)
        )

        if (dish.isSpecial) {
          Surface(
            color = DhabaGoldDark,
            shape = RoundedCornerShape(bottomEnd = 8.dp),
            modifier = Modifier.align(Alignment.TopStart)
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                imageVector = Icons.Default.Star,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(10.dp)
              )
              Spacer(modifier = Modifier.width(2.dp))
              Text(
                text = "Special",
                color = Color.White,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.width(14.dp))

      // Dish details
      Column(
        modifier = Modifier.weight(1f)
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically
        ) {
          // Veg / Non-Veg Indicator
          VegBadge(isVeg = dish.isVeg)
          Spacer(modifier = Modifier.width(6.dp))

          Text(
            text = dish.name,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
        }

        if (dish.isSundayOnly) {
          Spacer(modifier = Modifier.height(2.dp))
          Surface(
            color = DhabaSundayPurple.copy(alpha = 0.12f),
            shape = RoundedCornerShape(4.dp)
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                imageVector = Icons.Default.CalendarToday,
                contentDescription = null,
                tint = DhabaSundayPurple,
                modifier = Modifier.size(11.dp)
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = "Sunday Only Handi",
                color = DhabaSundayPurple,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(3.dp))
        Text(
          text = dish.description,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f),
          maxLines = 2,
          overflow = TextOverflow.Ellipsis
        )

        Spacer(modifier = Modifier.height(6.dp))

        // Price and Availability
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          if (showPrice && dish.price != null && dish.price > 0) {
            Text(
              text = "₹${dish.price.toInt()}",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.ExtraBold,
              color = DhabaRedPrimary
            )
          } else {
            Text(
              text = "Dhaba Fresh",
              style = MaterialTheme.typography.bodySmall,
              fontWeight = FontWeight.Medium,
              color = DhabaGoldDark
            )
          }

          // Cart Controls or Sold Out
          if (!dish.isAvailable) {
            Surface(
              color = Color.LightGray.copy(alpha = 0.3f),
              shape = RoundedCornerShape(8.dp)
            ) {
              Text(
                text = "Sold Out",
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                fontSize = 12.sp,
                color = Color.Gray,
                fontWeight = FontWeight.SemiBold
              )
            }
          } else if (cartItem != null && cartItem.quantity > 0) {
            // Quantity Selector
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier
                .background(
                  color = MaterialTheme.colorScheme.primaryContainer,
                  shape = RoundedCornerShape(10.dp)
                )
                .padding(horizontal = 4.dp, vertical = 2.dp)
            ) {
              IconButton(
                onClick = { onUpdateQuantity(dish.id, cartItem.quantity - 1) },
                modifier = Modifier
                  .size(32.dp)
                  .testTag("qty_minus_${dish.id}")
              ) {
                Icon(
                  imageVector = Icons.Default.Remove,
                  contentDescription = "Decrease quantity",
                  tint = DhabaRedPrimary,
                  modifier = Modifier.size(16.dp)
                )
              }
              Text(
                text = "${cartItem.quantity}",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = DhabaRedPrimary,
                modifier = Modifier.padding(horizontal = 6.dp)
              )
              IconButton(
                onClick = { onUpdateQuantity(dish.id, cartItem.quantity + 1) },
                modifier = Modifier
                  .size(32.dp)
                  .testTag("qty_plus_${dish.id}")
              ) {
                Icon(
                  imageVector = Icons.Default.Add,
                  contentDescription = "Increase quantity",
                  tint = DhabaRedPrimary,
                  modifier = Modifier.size(16.dp)
                )
              }
            }
          } else {
            // Add button
            ElevatedButton(
              onClick = { onAddToCart(dish) },
              modifier = Modifier.testTag("add_to_cart_${dish.id}"),
              colors = ButtonDefaults.elevatedButtonColors(
                containerColor = DhabaRedPrimary,
                contentColor = Color.White
              ),
              shape = RoundedCornerShape(10.dp),
              contentPadding = androidx.compose.foundation.layout.PaddingValues(
                horizontal = 14.dp,
                vertical = 6.dp
              )
            ) {
              Icon(
                imageVector = Icons.Default.Add,
                contentDescription = null,
                modifier = Modifier.size(14.dp)
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = "ADD",
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
              )
            }
          }
        }
      }
    }
  }
}

@Composable
fun VegBadge(isVeg: Boolean) {
  val borderColor = if (isVeg) DhabaVegGreen else DhabaNonVegRed
  Box(
    modifier = Modifier
      .size(14.dp)
      .border(1.2.dp, borderColor, RoundedCornerShape(3.dp)),
    contentAlignment = Alignment.Center
  ) {
    Box(
      modifier = Modifier
        .size(6.dp)
        .background(borderColor, CircleShape)
    )
  }
}
