package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.RestaurantMenu
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.DhabaRepository
import com.example.ui.theme.DhabaCharcoal
import com.example.ui.theme.DhabaGold
import com.example.ui.theme.DhabaGoldLight
import com.example.ui.theme.DhabaRedDark
import com.example.ui.theme.DhabaRedPrimary
import com.example.ui.theme.DhabaVegGreen
import com.example.ui.theme.DhabaWhatsAppGreen

@Composable
fun DhabaTopBar(
  isOpen: Boolean,
  onWhatsAppClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current

  Surface(
    modifier = modifier.fillMaxWidth(),
    color = DhabaRedPrimary,
    shadowElevation = 6.dp
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .background(
          Brush.verticalGradient(
            colors = listOf(DhabaRedDark, DhabaRedPrimary)
          )
        )
        .statusBarsPadding()
        .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Logo & Title
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.weight(1f)
        ) {
          Box(
            modifier = Modifier
              .size(44.dp)
              .background(DhabaGold, CircleShape),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.RestaurantMenu,
              contentDescription = "Ajay Pahadi Dhaba",
              tint = DhabaRedDark,
              modifier = Modifier.size(24.dp)
            )
          }

          Spacer(modifier = Modifier.width(10.dp))

          Column {
            Text(
              text = DhabaRepository.RESTAURANT_NAME,
              style = MaterialTheme.typography.titleLarge,
              fontWeight = FontWeight.Black,
              color = Color.White,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis
            )
            Text(
              text = DhabaRepository.RESTAURANT_TAGLINE,
              style = MaterialTheme.typography.bodySmall,
              fontStyle = FontStyle.Italic,
              color = DhabaGoldLight,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis
            )
          }
        }

        // Direct Call Button
        IconButton(
          onClick = {
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:+919317404470"))
            context.startActivity(intent)
          },
          modifier = Modifier
            .size(38.dp)
            .background(Color.White.copy(alpha = 0.15f), CircleShape)
        ) {
          Icon(
            imageVector = Icons.Default.Call,
            contentDescription = "Call Dhaba",
            tint = Color.White,
            modifier = Modifier.size(18.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      // Status Bar & Location Info
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Status badge
        Surface(
          color = if (isOpen) DhabaVegGreen.copy(alpha = 0.25f) else Color.Red.copy(alpha = 0.35f),
          shape = RoundedCornerShape(12.dp)
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Box(
              modifier = Modifier
                .size(6.dp)
                .background(if (isOpen) Color(0xFF4ADE80) else Color.Red, CircleShape)
            )
            Spacer(modifier = Modifier.width(5.dp))
            Text(
              text = if (isOpen) "Open Now • 7 AM - 11:30 PM" else "Currently Closed",
              color = Color.White,
              fontSize = 11.sp,
              fontWeight = FontWeight.SemiBold
            )
          }
        }

        // Location text
        Row(
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(
            imageVector = Icons.Default.LocationOn,
            contentDescription = null,
            tint = DhabaGoldLight,
            modifier = Modifier.size(13.dp)
          )
          Spacer(modifier = Modifier.width(3.dp))
          Text(
            text = DhabaRepository.RESTAURANT_LOCATION,
            color = Color.White.copy(alpha = 0.9f),
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium
          )
        }
      }
    }
  }
}
