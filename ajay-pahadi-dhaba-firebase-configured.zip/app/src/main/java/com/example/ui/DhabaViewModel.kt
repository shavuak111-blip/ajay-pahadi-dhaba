package com.example.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.DhabaDatabase
import com.example.data.model.CartItem
import com.example.data.model.DhabaSettings
import com.example.data.model.DishItem
import com.example.data.model.MealFilter
import com.example.data.model.MenuCategory
import com.example.data.model.OrderRecord
import com.example.data.model.OrderStatus
import com.example.data.model.OrderType
import com.example.data.repository.DhabaRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AppScreen(val title: String) {
  HOME("Home"),
  MENU("Menu"),
  CART("Cart"),
  ORDERS("My Orders"),
  ADMIN("Dhaba Admin")
}

data class DhabaUiState(
  val currentScreen: AppScreen = AppScreen.HOME,
  val searchQuery: String = "",
  val selectedCategory: MenuCategory? = null,
  val selectedMealFilter: MealFilter = MealFilter.ALL,
  val onlyVegFilter: Boolean = false,
  val cartItems: List<CartItem> = emptyList(),
  val customerName: String = "",
  val customerPhone: String = "",
  val deliveryAddress: String = "",
  val orderType: OrderType = OrderType.DELIVERY,
  val specialInstructions: String = "",
  val lastPlacedOrder: OrderRecord? = null,
  val isAdminUnlocked: Boolean = false,
  val editingDish: DishItem? = null,
  val toastMessage: String? = null
)

class DhabaViewModel(application: Application) : AndroidViewModel(application) {

  private val database = DhabaDatabase.getDatabase(application)
  private val repository = DhabaRepository(database.dhabaDao(), application)

  private val _uiState = MutableStateFlow(DhabaUiState())
  val uiState: StateFlow<DhabaUiState> = _uiState.asStateFlow()

  val allDishes: StateFlow<List<DishItem>> = repository.allDishesFlow.stateIn(
    viewModelScope,
    SharingStarted.WhileSubscribed(5000),
    emptyList()
  )

  val settings: StateFlow<DhabaSettings> = repository.settingsFlow.stateIn(
    viewModelScope,
    SharingStarted.WhileSubscribed(5000),
    DhabaSettings()
  )

  val allOrders: StateFlow<List<OrderRecord>> = repository.ordersFlow.stateIn(
    viewModelScope,
    SharingStarted.WhileSubscribed(5000),
    emptyList()
  )

  // Filtered customer catalog
  val customerDishes: StateFlow<List<DishItem>> = combine(
    allDishes,
    settings,
    _uiState
  ) { dishes, setting, state ->
    val isSunday = repository.isTodaySunday() || setting.forceSundaySpecial
    dishes.filter { dish ->
      // Sunday-only filter rule
      val sundayOk = !dish.isSundayOnly || isSunday

      // Veg filter rule
      val vegOk = !state.onlyVegFilter || dish.isVeg

      // Meal filter rule
      val mealOk = when (state.selectedMealFilter) {
        MealFilter.ALL -> true
        MealFilter.BREAKFAST -> dish.mealTimes.contains("BREAKFAST")
        MealFilter.LUNCH -> dish.mealTimes.contains("LUNCH")
        MealFilter.DINNER -> dish.mealTimes.contains("DINNER")
      }

      // Category filter rule
      val categoryOk = state.selectedCategory == null ||
        dish.category.equals(state.selectedCategory.name, ignoreCase = true)

      // Search query rule
      val searchOk = state.searchQuery.isBlank() ||
        dish.name.contains(state.searchQuery, ignoreCase = true) ||
        dish.description.contains(state.searchQuery, ignoreCase = true) ||
        dish.category.contains(state.searchQuery, ignoreCase = true)

      sundayOk && vegOk && mealOk && categoryOk && searchOk
    }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  init {
    viewModelScope.launch {
      repository.ensureMenuPopulated()
    }
  }

  fun navigateTo(screen: AppScreen) {
    _uiState.value = _uiState.value.copy(currentScreen = screen)
  }

  fun setSearchQuery(query: String) {
    _uiState.value = _uiState.value.copy(searchQuery = query)
  }

  fun selectCategory(category: MenuCategory?) {
    _uiState.value = _uiState.value.copy(
      selectedCategory = if (_uiState.value.selectedCategory == category) null else category
    )
  }

  fun selectMealFilter(filter: MealFilter) {
    _uiState.value = _uiState.value.copy(selectedMealFilter = filter)
  }

  fun toggleVegFilter() {
    _uiState.value = _uiState.value.copy(onlyVegFilter = !_uiState.value.onlyVegFilter)
  }

  fun addToCart(dish: DishItem) {
    if (!dish.isAvailable) {
      showToast("${dish.name} is currently sold out")
      return
    }
    val currentCart = _uiState.value.cartItems.toMutableList()
    val existingIndex = currentCart.indexOfFirst { it.dish.id == dish.id }
    if (existingIndex >= 0) {
      val existing = currentCart[existingIndex]
      currentCart[existingIndex] = existing.copy(quantity = existing.quantity + 1)
    } else {
      currentCart.add(CartItem(dish = dish, quantity = 1))
    }
    _uiState.value = _uiState.value.copy(cartItems = currentCart)
    showToast("Added ${dish.name} to cart")
  }

  fun updateCartQuantity(dishId: String, newQuantity: Int) {
    val currentCart = _uiState.value.cartItems.toMutableList()
    val existingIndex = currentCart.indexOfFirst { it.dish.id == dishId }
    if (existingIndex >= 0) {
      if (newQuantity <= 0) {
        currentCart.removeAt(existingIndex)
      } else {
        currentCart[existingIndex] = currentCart[existingIndex].copy(quantity = newQuantity)
      }
      _uiState.value = _uiState.value.copy(cartItems = currentCart)
    }
  }

  fun removeFromCart(dishId: String) {
    val currentCart = _uiState.value.cartItems.filterNot { it.dish.id == dishId }
    _uiState.value = _uiState.value.copy(cartItems = currentCart)
  }

  fun clearCart() {
    _uiState.value = _uiState.value.copy(cartItems = emptyList())
  }

  fun setCustomerName(name: String) {
    _uiState.value = _uiState.value.copy(customerName = name)
  }

  fun setCustomerPhone(phone: String) {
    _uiState.value = _uiState.value.copy(customerPhone = phone)
  }

  fun setDeliveryAddress(address: String) {
    _uiState.value = _uiState.value.copy(deliveryAddress = address)
  }

  fun setOrderType(type: OrderType) {
    _uiState.value = _uiState.value.copy(orderType = type)
  }

  fun setSpecialInstructions(instructions: String) {
    _uiState.value = _uiState.value.copy(specialInstructions = instructions)
  }

  fun clearToast() {
    _uiState.value = _uiState.value.copy(toastMessage = null)
  }

  private fun showToast(msg: String) {
    _uiState.value = _uiState.value.copy(toastMessage = msg)
  }

  // Ordering logic
  fun calculateTotal(cartItems: List<CartItem>, showPrices: Boolean): Double? {
    if (!showPrices) return null
    var hasValidPrices = false
    var sum = 0.0
    for (item in cartItems) {
      val p = item.dish.price
      if (p != null && p > 0) {
        hasValidPrices = true
        sum += p * item.quantity
      } else {
        // If some item has no price set, total is incomplete
        return null
      }
    }
    return if (hasValidPrices) sum else null
  }

  fun placeWhatsAppOrder(context: Context): Boolean {
    val state = _uiState.value
    if (state.cartItems.isEmpty()) {
      showToast("Your cart is empty!")
      return false
    }
    if (state.customerName.isBlank()) {
      showToast("Please enter your name")
      return false
    }
    if (state.customerPhone.isBlank()) {
      showToast("Please enter your mobile number")
      return false
    }
    if (state.orderType == OrderType.DELIVERY && state.deliveryAddress.isBlank()) {
      showToast("Please enter your delivery address")
      return false
    }

    val total = calculateTotal(state.cartItems, settings.value.showPrices)
    val msg = repository.generateWhatsAppMessage(
      orderId = null,
      customerName = state.customerName,
      phone = state.customerPhone,
      address = state.deliveryAddress,
      orderType = state.orderType,
      items = state.cartItems,
      specialInstructions = state.specialInstructions,
      totalAmount = total,
      showPrices = settings.value.showPrices
    )

    // Save as local order record as well for tracking
    viewModelScope.launch {
      val record = repository.saveOrder(
        customerName = state.customerName,
        phone = state.customerPhone,
        address = state.deliveryAddress,
        orderType = state.orderType,
        items = state.cartItems,
        specialInstructions = state.specialInstructions,
        totalAmount = total,
        deliveryFee = settings.value.deliveryCharge
      )
      _uiState.value = _uiState.value.copy(
        lastPlacedOrder = record,
        cartItems = emptyList()
      )
    }

    val opened = repository.launchWhatsApp(context, msg)
    if (!opened) {
      showToast("WhatsApp not found. Order saved locally under My Orders.")
    }
    return true
  }

  fun placeOnlineOrder(): Boolean {
    val state = _uiState.value
    if (state.cartItems.isEmpty()) {
      showToast("Your cart is empty!")
      return false
    }
    if (state.customerName.isBlank()) {
      showToast("Please enter your name")
      return false
    }
    if (state.customerPhone.isBlank()) {
      showToast("Please enter your phone number")
      return false
    }
    if (state.orderType == OrderType.DELIVERY && state.deliveryAddress.isBlank()) {
      showToast("Please enter your delivery address")
      return false
    }

    val total = calculateTotal(state.cartItems, settings.value.showPrices)
    viewModelScope.launch {
      val record = repository.saveOrder(
        customerName = state.customerName,
        phone = state.customerPhone,
        address = state.deliveryAddress,
        orderType = state.orderType,
        items = state.cartItems,
        specialInstructions = state.specialInstructions,
        totalAmount = total,
        deliveryFee = settings.value.deliveryCharge
      )
      _uiState.value = _uiState.value.copy(
        lastPlacedOrder = record,
        cartItems = emptyList()
      )
      showToast("Order #${record.id} placed successfully!")
    }
    return true
  }

  // Admin Controls
  fun unlockAdmin(pin: String): Boolean {
    return if (pin.trim() == "1234" || pin.trim() == "0000" || pin.trim() == "9317") {
      _uiState.value = _uiState.value.copy(isAdminUnlocked = true)
      true
    } else {
      showToast("Incorrect Dhaba PIN (Use default 1234)")
      false
    }
  }

  fun lockAdmin() {
    _uiState.value = _uiState.value.copy(isAdminUnlocked = false, editingDish = null)
  }

  fun toggleShowPrices(show: Boolean) {
    viewModelScope.launch {
      repository.updateSettings(settings.value.copy(showPrices = show))
      showToast(if (show) "Customer prices are now VISIBLE" else "Customer prices are now HIDDEN")
    }
  }

  fun toggleForceSunday(force: Boolean) {
    viewModelScope.launch {
      repository.updateSettings(settings.value.copy(forceSundaySpecial = force))
      showToast(if (force) "Sunday Specials force-enabled for customers" else "Sunday Specials auto-detecting Sunday")
    }
  }

  fun toggleRestaurantOpen(isOpen: Boolean) {
    viewModelScope.launch {
      repository.updateSettings(settings.value.copy(isRestaurantOpen = isOpen))
      showToast(if (isOpen) "Restaurant status: OPEN" else "Restaurant status: CLOSED")
    }
  }

  fun toggleDishAvailability(dishId: String, current: Boolean) {
    viewModelScope.launch {
      repository.updateDishAvailability(dishId, !current)
      showToast(if (!current) "Dish marked Available" else "Dish marked Sold Out")
    }
  }

  fun updateDishPrice(dishId: String, price: Double?) {
    viewModelScope.launch {
      repository.updateDishPrice(dishId, price)
      showToast("Price updated")
    }
  }

  fun setEditingDish(dish: DishItem?) {
    _uiState.value = _uiState.value.copy(editingDish = dish)
  }

  fun saveDish(dish: DishItem) {
    viewModelScope.launch {
      repository.saveDish(dish)
      _uiState.value = _uiState.value.copy(editingDish = null)
      showToast("Dish saved successfully")
    }
  }

  fun deleteDish(dishId: String) {
    viewModelScope.launch {
      repository.deleteDish(dishId)
      showToast("Dish deleted")
    }
  }

  fun updateOrderStatus(orderId: String, newStatus: OrderStatus) {
    viewModelScope.launch {
      repository.updateOrderStatus(orderId, newStatus)
      showToast("Order status updated to ${newStatus.title}")
    }
  }

  fun notifyCustomerOnWhatsApp(context: Context, order: OrderRecord) {
    val statusMsg = "Namaste ${order.customerName}! 🙏\nUpdate from *Ajay Pahadi Dhaba* regarding your order *#${order.id}*:\n\n*Status:* ${order.status.title}\n\nThank you for choosing Ghar Jaisa Swad!"
    repository.launchWhatsApp(context, statusMsg)
  }
}
