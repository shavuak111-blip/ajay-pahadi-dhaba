package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BakeryDining
import androidx.compose.material.icons.filled.BreakfastDining
import androidx.compose.material.icons.filled.Coffee
import androidx.compose.material.icons.filled.DinnerDining
import androidx.compose.material.icons.filled.Egg
import androidx.compose.material.icons.filled.Fastfood
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.LunchDining
import androidx.compose.material.icons.filled.RamenDining
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.RiceBowl
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.example.ui.theme.DhabaGold
import com.example.ui.theme.DhabaRedPrimary

@Composable
fun DishIllustration(
  imageIdentifier: String,
  category: String,
  isVeg: Boolean,
  modifier: Modifier = Modifier
) {
  val (icon, gradient) = when (imageIdentifier.lowercase()) {
    "tawa_chicken" -> Pair(
      Icons.Default.LocalFireDepartment,
      Brush.linearGradient(listOf(Color(0xFF7F1D1D), Color(0xFFB91C1C), Color(0xFFD97706)))
    )
    "fry_chicken", "chicken_pakora" -> Pair(
      Icons.Default.Fastfood,
      Brush.linearGradient(listOf(Color(0xFF9A3412), Color(0xFFD97706), Color(0xFFFBBF24)))
    )
    "chicken_gravy", "chicken_thali" -> Pair(
      Icons.Default.DinnerDining,
      Brush.linearGradient(listOf(Color(0xFF881337), Color(0xFFBE123C), Color(0xFFFB7185)))
    )
    "egg_curry", "egg_roll" -> Pair(
      Icons.Default.Egg,
      Brush.linearGradient(listOf(Color(0xFFB45309), Color(0xFFF59E0B), Color(0xFFFEF08A)))
    )
    "veg_thali", "rajma_rice", "dal_rice", "rice" -> Pair(
      Icons.Default.RiceBowl,
      Brush.linearGradient(listOf(Color(0xFF14532D), Color(0xFF16A34A), Color(0xFF86EFAC)))
    )
    "butter_roti", "chapati" -> Pair(
      Icons.Default.BakeryDining,
      Brush.linearGradient(listOf(Color(0xFF78350F), Color(0xFFD97706), Color(0xFFFDE68A)))
    )
    "aloo_parantha", "paneer_parantha", "mix_parantha", "gobhi_parantha" -> Pair(
      Icons.Default.BreakfastDining,
      Brush.linearGradient(listOf(Color(0xFF854D0E), Color(0xFFCA8A04), Color(0xFFFEF08A)))
    )
    "chowmein", "fried_rice", "burger", "spring_roll" -> Pair(
      Icons.Default.RamenDining,
      Brush.linearGradient(listOf(Color(0xFF831843), Color(0xFFC026D3), Color(0xFFF472B6)))
    )
    "tea_chai", "mineral_water", "khara_soda" -> Pair(
      Icons.Default.Coffee,
      Brush.linearGradient(listOf(Color(0xFF451A03), Color(0xFF92400E), Color(0xFFFDE68A)))
    )
    "sunday_mutton", "mutton_curry", "keema_roti" -> Pair(
      Icons.Default.LocalFireDepartment,
      Brush.linearGradient(listOf(Color(0xFF581C87), Color(0xFF7E22CE), Color(0xFFA855F7)))
    )
    else -> Pair(
      if (isVeg) Icons.Default.LunchDining else Icons.Default.Restaurant,
      Brush.linearGradient(listOf(DhabaRedPrimary, DhabaGold))
    )
  }

  Box(
    modifier = modifier
      .clip(RoundedCornerShape(12.dp))
      .background(gradient),
    contentAlignment = Alignment.Center
  ) {
    Icon(
      imageVector = icon,
      contentDescription = null,
      tint = Color.White.copy(alpha = 0.92f),
      modifier = Modifier.size(36.dp)
    )
  }
}
