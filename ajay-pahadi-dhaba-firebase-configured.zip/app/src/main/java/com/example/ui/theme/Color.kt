package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Deep Red Dhaba Brand Colors
val DhabaRedPrimary = Color(0xFF991B1B)
val DhabaRedDark = Color(0xFF7F1D1D)
val DhabaRedLight = Color(0xFFEF4444)
val DhabaRedContainer = Color(0xFFFEE2E2)
val DhabaOnRedContainer = Color(0xFF7F1D1D)

// Secondary & Dark Slate / Black Colors
val DhabaCharcoal = Color(0xFF1C1917)
val DhabaDarkSurface = Color(0xFF18181B)
val DhabaMutedText = Color(0xFF71717A)

// Accent Golden Yellow / Warm Amber Colors
val DhabaGold = Color(0xFFF59E0B)
val DhabaGoldDark = Color(0xFFD97706)
val DhabaGoldLight = Color(0xFFFEF3C7)
val DhabaGoldBright = Color(0xFFFBBF24)

// Background & Warm Cream
val DhabaCreamBg = Color(0xFFFAF7F0)
val DhabaCreamSurface = Color(0xFFFFFFFF)
val DhabaCreamCard = Color(0xFFFFFDF8)
val DhabaBorder = Color(0xFFE5E0D8)

// Food Category Indicators
val DhabaVegGreen = Color(0xFF15803D)
val DhabaNonVegRed = Color(0xFFB91C1C)
val DhabaSundayPurple = Color(0xFF7C3AED)
val DhabaWhatsAppGreen = Color(0xFF25D366)
