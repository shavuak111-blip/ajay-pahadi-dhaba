package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CartItem
import com.example.data.model.DishItem
import com.example.data.model.MenuCategory
import com.example.ui.components.DishCard
import com.example.ui.theme.DhabaBorder
import com.example.ui.theme.DhabaGold
import com.example.ui.theme.DhabaGoldDark
import com.example.ui.theme.DhabaRedPrimary
import com.example.ui.theme.DhabaSundayPurple
import com.example.ui.theme.DhabaVegGreen

@Composable
fun MenuScreen(
  dishes: List<DishItem>,
  cartItems: List<CartItem>,
  showPrices: Boolean,
  selectedCategory: MenuCategory?,
  onlyVegFilter: Boolean,
  searchQuery: String,
  onCategorySelect: (MenuCategory?) -> Unit,
  onToggleVeg: () -> Unit,
  onSearchChange: (String) -> Unit,
  onAddToCart: (DishItem) -> Unit,
  onUpdateQuantity: (String, Int) -> Unit,
  modifier: Modifier = Modifier
) {
  val allCategories = listOf(null) + MenuCategory.entries.toList()
  val selectedTabIndex = allCategories.indexOf(selectedCategory).let { if (it < 0) 0 else it }

  Column(
    modifier = modifier
      .fillMaxSize()
      .testTag("menu_screen_content")
  ) {
    // Search & Filter header
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .background(Color.White)
        .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
      OutlinedTextField(
        value = searchQuery,
        onValueChange = onSearchChange,
        modifier = Modifier
          .fillMaxWidth()
          .testTag("menu_search_input"),
        placeholder = { Text("Search menu dishes, ingredients...", fontSize = 13.sp) },
        leadingIcon = {
          Icon(
            imageVector = Icons.Default.Search,
            contentDescription = null,
            tint = DhabaRedPrimary
          )
        },
        trailingIcon = {
          if (searchQuery.isNotEmpty()) {
            IconButton(onClick = { onSearchChange("") }) {
              Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear")
            }
          }
        },
        shape = RoundedCornerShape(14.dp),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = DhabaRedPrimary,
          unfocusedBorderColor = DhabaBorder
        ),
        singleLine = true
      )

      Spacer(modifier = Modifier.height(8.dp))

      // Veg Toggle Chip
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        FilterChip(
          selected = onlyVegFilter,
          onClick = onToggleVeg,
          label = {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(8.dp)
                  .background(DhabaVegGreen, CircleShape)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text("Veg Only", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
          },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = DhabaVegGreen,
            selectedLabelColor = Color.White
          ),
          shape = RoundedCornerShape(16.dp)
        )

        Text(
          text = "${dishes.size} items listed",
          style = MaterialTheme.typography.bodySmall,
          color = Color.Gray
        )
      }
    }

    // Category Tabs
    ScrollableTabRow(
      selectedTabIndex = selectedTabIndex,
      containerColor = Color.White,
      contentColor = DhabaRedPrimary,
      edgePadding = 16.dp,
      indicator = { tabPositions ->
        TabRowDefaults.SecondaryIndicator(
          modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
          color = DhabaRedPrimary,
          height = 3.dp
        )
      }
    ) {
      allCategories.forEachIndexed { index, cat ->
        Tab(
          selected = index == selectedTabIndex,
          onClick = { onCategorySelect(cat) },
          text = {
            Text(
              text = cat?.displayName ?: "All Items",
              fontWeight = if (index == selectedTabIndex) FontWeight.Bold else FontWeight.Medium,
              fontSize = 13.sp,
              color = if (index == selectedTabIndex) DhabaRedPrimary else Color(0xFF52525B)
            )
          }
        )
      }
    }

    // Category Banner Info
    if (selectedCategory == MenuCategory.SUNDAY_SPECIAL) {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 8.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = DhabaSundayPurple.copy(alpha = 0.08f)),
        border = BorderStroke(1.dp, DhabaSundayPurple.copy(alpha = 0.2f))
      ) {
        Row(
          modifier = Modifier.padding(12.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(
            imageVector = Icons.Default.CalendarToday,
            contentDescription = null,
            tint = DhabaSundayPurple,
            modifier = Modifier.size(20.dp)
          )
          Spacer(modifier = Modifier.width(10.dp))
          Text(
            text = "Sunday Specials: Slow woodfire mutton handi & keema prepared in limited batches every Sunday.",
            style = MaterialTheme.typography.bodySmall,
            color = DhabaSundayPurple,
            fontWeight = FontWeight.Medium
          )
        }
      }
    }

    // Dish List
    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 90.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      if (dishes.isEmpty()) {
        item {
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, DhabaBorder)
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Icon(
                imageVector = Icons.Default.Restaurant,
                contentDescription = null,
                tint = DhabaGoldDark,
                modifier = Modifier.size(44.dp)
              )
              Spacer(modifier = Modifier.height(12.dp))
              Text(
                text = "No items found in this section",
                fontWeight = FontWeight.Bold
              )
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = "Check another category or clear your search filter.",
                fontSize = 12.sp,
                color = Color.Gray
              )
            }
          }
        }
      } else {
        items(dishes, key = { it.id }) { dish ->
          val cartItem = cartItems.find { it.dish.id == dish.id }
          DishCard(
            dish = dish,
            cartItem = cartItem,
            showPrice = showPrices,
            onAddToCart = onAddToCart,
            onUpdateQuantity = onUpdateQuantity
          )
        }
      }
    }
  }
}
