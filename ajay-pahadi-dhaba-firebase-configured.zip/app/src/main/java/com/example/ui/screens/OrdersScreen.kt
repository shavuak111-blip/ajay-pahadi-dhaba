package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeliveryDining
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.OutdoorGrill
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.OrderRecord
import com.example.data.model.OrderStatus
import com.example.data.model.OrderType
import com.example.data.repository.DhabaRepository
import com.example.ui.theme.DhabaBorder
import com.example.ui.theme.DhabaGold
import com.example.ui.theme.DhabaGoldDark
import com.example.ui.theme.DhabaGoldLight
import com.example.ui.theme.DhabaRedDark
import com.example.ui.theme.DhabaRedPrimary
import com.example.ui.theme.DhabaWhatsAppGreen
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun OrdersScreen(
  orders: List<OrderRecord>,
  showPrices: Boolean,
  onInquireWhatsApp: (OrderRecord) -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current

  Column(
    modifier = modifier
      .fillMaxSize()
      .testTag("orders_screen_content")
  ) {
    // Header
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .background(Color.White)
        .padding(16.dp)
    ) {
      Text(
        text = "Your Dhaba Orders",
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.Black,
        color = DhabaRedPrimary
      )
      Text(
        text = "Track live kitchen preparation, delivery and order status",
        style = MaterialTheme.typography.bodySmall,
        color = Color.Gray
      )
    }

    if (orders.isEmpty()) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
      ) {
        Box(
          modifier = Modifier
            .size(80.dp)
            .background(DhabaGoldLight, CircleShape),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.ReceiptLong,
            contentDescription = null,
            tint = DhabaGoldDark,
            modifier = Modifier.size(40.dp)
          )
        }
        Spacer(modifier = Modifier.height(16.dp))
        Text(
          text = "No Orders Placed Yet",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = "Your confirmed orders and live preparation updates will appear here.",
          style = MaterialTheme.typography.bodySmall,
          color = Color.Gray,
          textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
      }
    } else {
      LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
      ) {
        items(orders, key = { it.id }) { order ->
          OrderItemCard(
            order = order,
            showPrices = showPrices,
            onInquireWhatsApp = { onInquireWhatsApp(order) },
            onCallDhaba = {
              val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:+919317404470"))
              context.startActivity(intent)
            }
          )
        }
      }
    }
  }
}

@Composable
fun OrderItemCard(
  order: OrderRecord,
  showPrices: Boolean,
  onInquireWhatsApp: () -> Unit,
  onCallDhaba: () -> Unit
) {
  val dateFormat = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())
  val dateStr = dateFormat.format(Date(order.timestamp))

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("order_item_${order.id}"),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = Color.White),
    border = BorderStroke(1.dp, DhabaBorder),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp)
    ) {
      // Header: Order ID & Status
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "#${order.id}",
            fontWeight = FontWeight.Black,
            fontSize = 15.sp,
            color = DhabaRedPrimary
          )
          Text(
            text = dateStr,
            fontSize = 11.sp,
            color = Color.Gray
          )
        }

        // Live status badge
        Surface(
          color = Color(order.status.badgeColorHex).copy(alpha = 0.15f),
          shape = RoundedCornerShape(12.dp)
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Box(
              modifier = Modifier
                .size(7.dp)
                .background(Color(order.status.badgeColorHex), CircleShape)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = order.status.title,
              color = Color(order.status.badgeColorHex),
              fontWeight = FontWeight.Bold,
              fontSize = 12.sp
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(10.dp))
      HorizontalDivider(color = DhabaBorder.copy(alpha = 0.6f))
      Spacer(modifier = Modifier.height(10.dp))

      // Customer and delivery type
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = if (order.orderType == OrderType.DELIVERY) Icons.Default.DeliveryDining else Icons.Default.Restaurant,
          contentDescription = null,
          tint = DhabaRedPrimary,
          modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = order.orderType.displayName,
          fontWeight = FontWeight.SemiBold,
          fontSize = 12.sp
        )
      }

      if (order.orderType == OrderType.DELIVERY && order.address.isNotBlank()) {
        Spacer(modifier = Modifier.height(4.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Default.LocationOn,
            contentDescription = null,
            tint = Color.Gray,
            modifier = Modifier.size(14.dp)
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = order.address,
            fontSize = 11.sp,
            color = Color.Gray
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Ordered Items
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .background(Color(0xFFFBF9F5), RoundedCornerShape(10.dp))
          .padding(10.dp)
      ) {
        order.items.forEach { item ->
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(
              text = "${item.quantity}x ${item.dish.name}",
              fontSize = 13.sp,
              fontWeight = FontWeight.Medium
            )
            if (showPrices && item.dish.price != null && item.dish.price > 0) {
              Text(
                text = "₹${(item.dish.price * item.quantity).toInt()}",
                fontSize = 12.sp,
                color = Color.DarkGray
              )
            }
          }
        }

        if (order.specialInstructions.isNotBlank()) {
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = "Note: \"${order.specialInstructions}\"",
            fontSize = 11.sp,
            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
            color = DhabaGoldDark
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Actions: Inquire on WhatsApp or Call
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        OutlinedButton(
          onClick = onInquireWhatsApp,
          modifier = Modifier.weight(1f),
          shape = RoundedCornerShape(10.dp),
          colors = ButtonDefaults.outlinedButtonColors(contentColor = DhabaWhatsAppGreen),
          border = BorderStroke(1.dp, DhabaWhatsAppGreen)
        ) {
          Icon(
            imageVector = Icons.Default.Chat,
            contentDescription = null,
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(text = "WhatsApp Dhaba", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }

        OutlinedButton(
          onClick = onCallDhaba,
          modifier = Modifier.weight(1f),
          shape = RoundedCornerShape(10.dp),
          colors = ButtonDefaults.outlinedButtonColors(contentColor = DhabaRedPrimary),
          border = BorderStroke(1.dp, DhabaRedPrimary)
        ) {
          Icon(
            imageVector = Icons.Default.Call,
            contentDescription = null,
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(text = "Call Counter", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}
