package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.repository.DhabaRepository
import com.example.ui.AppScreen
import com.example.ui.DhabaViewModel
import com.example.ui.components.DhabaBottomNav
import com.example.ui.components.DhabaTopBar
import com.example.ui.screens.AdminScreen
import com.example.ui.screens.CartScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MenuScreen
import com.example.ui.screens.OrdersScreen
import com.example.ui.theme.DhabaGold
import com.example.ui.theme.DhabaRedPrimary
import com.example.ui.theme.DhabaTheme
import com.example.ui.theme.DhabaWhatsAppGreen

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      DhabaTheme {
        DhabaMainApp()
      }
    }
  }
}

@Composable
fun DhabaMainApp(
  viewModel: DhabaViewModel = viewModel()
) {
  val context = LocalContext.current
  val uiState by viewModel.uiState.collectAsStateWithLifecycle()
  val customerDishes by viewModel.customerDishes.collectAsStateWithLifecycle()
  val allDishes by viewModel.allDishes.collectAsStateWithLifecycle()
  val settings by viewModel.settings.collectAsStateWithLifecycle()
  val orders by viewModel.allOrders.collectAsStateWithLifecycle()

  val snackbarHostState = remember { SnackbarHostState() }

  // Handle hardware Back button when not on HOME screen
  BackHandler(enabled = uiState.currentScreen != AppScreen.HOME) {
    viewModel.navigateTo(AppScreen.HOME)
  }

  // Toast / feedback message collector
  LaunchedEffect(uiState.toastMessage) {
    uiState.toastMessage?.let { msg ->
      snackbarHostState.showSnackbar(msg)
      viewModel.clearToast()
    }
  }

  Scaffold(
    modifier = Modifier.fillMaxSize(),
    topBar = {
      DhabaTopBar(
        isOpen = settings.isRestaurantOpen,
        onWhatsAppClick = {
          val repo = DhabaRepository(
            com.example.data.local.DhabaDatabase.getDatabase(context).dhabaDao(),
            context
          )
          repo.launchWhatsApp(context, "Namaste Ajay Pahadi Dhaba! I would like to inquire about today's menu and specials.")
        }
      )
    },
    bottomBar = {
      DhabaBottomNav(
        currentScreen = uiState.currentScreen,
        cartItemCount = uiState.cartItems.sumOf { it.quantity },
        onScreenSelected = { screen -> viewModel.navigateTo(screen) }
      )
    },
    floatingActionButton = {
      // Floating Cart Quick Action when items are in cart and not currently on Cart screen
      AnimatedVisibility(
        visible = uiState.cartItems.isNotEmpty() && uiState.currentScreen != AppScreen.CART,
        enter = fadeIn(),
        exit = fadeOut()
      ) {
        ExtendedFloatingActionButton(
          onClick = { viewModel.navigateTo(AppScreen.CART) },
          containerColor = DhabaRedPrimary,
          contentColor = Color.White,
          elevation = FloatingActionButtonDefaults.elevation(defaultElevation = 6.dp),
          icon = {
            Icon(imageVector = Icons.Default.ShoppingCart, contentDescription = "View Cart")
          },
          text = {
            Text(
              text = "View Cart (${uiState.cartItems.sumOf { it.quantity }})",
              fontWeight = FontWeight.Bold
            )
          }
        )
      }
    },
    snackbarHost = { SnackbarHost(snackbarHostState) }
  ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
    ) {
      when (uiState.currentScreen) {
        AppScreen.HOME -> {
          HomeScreen(
            dishes = customerDishes,
            allDishes = allDishes,
            cartItems = uiState.cartItems,
            showPrices = settings.showPrices,
            searchQuery = uiState.searchQuery,
            selectedCategory = uiState.selectedCategory,
            selectedMealFilter = uiState.selectedMealFilter,
            onlyVegFilter = uiState.onlyVegFilter,
            onSearchChange = { viewModel.setSearchQuery(it) },
            onCategorySelect = { viewModel.selectCategory(it) },
            onMealFilterSelect = { viewModel.selectMealFilter(it) },
            onToggleVeg = { viewModel.toggleVegFilter() },
            onAddToCart = { viewModel.addToCart(it) },
            onUpdateQuantity = { id, qty -> viewModel.updateCartQuantity(id, qty) },
            onWhatsAppQuickOrder = {
              val repo = DhabaRepository(
                com.example.data.local.DhabaDatabase.getDatabase(context).dhabaDao(),
                context
              )
              repo.launchWhatsApp(
                context,
                "Namaste Ajay Pahadi Dhaba! Please send me today's specials and live menu rates."
              )
            }
          )
        }
        AppScreen.MENU -> {
          MenuScreen(
            dishes = customerDishes,
            cartItems = uiState.cartItems,
            showPrices = settings.showPrices,
            selectedCategory = uiState.selectedCategory,
            onlyVegFilter = uiState.onlyVegFilter,
            searchQuery = uiState.searchQuery,
            onCategorySelect = { viewModel.selectCategory(it) },
            onToggleVeg = { viewModel.toggleVegFilter() },
            onSearchChange = { viewModel.setSearchQuery(it) },
            onAddToCart = { viewModel.addToCart(it) },
            onUpdateQuantity = { id, qty -> viewModel.updateCartQuantity(id, qty) }
          )
        }
        AppScreen.CART -> {
          CartScreen(
            cartItems = uiState.cartItems,
            customerName = uiState.customerName,
            customerPhone = uiState.customerPhone,
            deliveryAddress = uiState.deliveryAddress,
            orderType = uiState.orderType,
            specialInstructions = uiState.specialInstructions,
            showPrices = settings.showPrices,
            lastPlacedOrder = uiState.lastPlacedOrder,
            onUpdateQuantity = { id, qty -> viewModel.updateCartQuantity(id, qty) },
            onRemoveItem = { viewModel.removeFromCart(it) },
            onCustomerNameChange = { viewModel.setCustomerName(it) },
            onCustomerPhoneChange = { viewModel.setCustomerPhone(it) },
            onDeliveryAddressChange = { viewModel.setDeliveryAddress(it) },
            onOrderTypeChange = { viewModel.setOrderType(it) },
            onSpecialInstructionsChange = { viewModel.setSpecialInstructions(it) },
            onPlaceWhatsAppOrder = { ctx -> viewModel.placeWhatsAppOrder(ctx) },
            onPlaceOnlineOrder = { viewModel.placeOnlineOrder() },
            onStartNewOrder = {
              viewModel.clearCart()
              viewModel.navigateTo(AppScreen.HOME)
            }
          )
        }
        AppScreen.ORDERS -> {
          OrdersScreen(
            orders = orders,
            showPrices = settings.showPrices,
            onInquireWhatsApp = { order ->
              val repo = DhabaRepository(
                com.example.data.local.DhabaDatabase.getDatabase(context).dhabaDao(),
                context
              )
              val inquiry = "Namaste Ajay Pahadi Dhaba! I am inquiring about my order *#${order.id}* placed for ${order.customerName}."
              repo.launchWhatsApp(context, inquiry)
            }
          )
        }
        AppScreen.ADMIN -> {
          AdminScreen(
            isUnlocked = uiState.isAdminUnlocked,
            settings = settings,
            orders = orders,
            dishes = allDishes,
            editingDish = uiState.editingDish,
            onUnlock = { pin -> viewModel.unlockAdmin(pin) },
            onLock = { viewModel.lockAdmin() },
            onToggleShowPrices = { viewModel.toggleShowPrices(it) },
            onToggleForceSunday = { viewModel.toggleForceSunday(it) },
            onToggleRestaurantOpen = { viewModel.toggleRestaurantOpen(it) },
            onToggleDishAvailability = { id, curr -> viewModel.toggleDishAvailability(id, curr) },
            onUpdateDishPrice = { id, price -> viewModel.updateDishPrice(id, price) },
            onSetEditingDish = { viewModel.setEditingDish(it) },
            onSaveDish = { viewModel.saveDish(it) },
            onDeleteDish = { viewModel.deleteDish(it) },
            onUpdateOrderStatus = { id, status -> viewModel.updateOrderStatus(id, status) },
            onNotifyCustomerWhatsApp = { ctx, order -> viewModel.notifyCustomerOnWhatsApp(ctx, order) }
          )
        }
      }
    }
  }
}
